import {
  mysqlTable, varchar, timestamp, bigint, int, mysqlEnum, boolean, text,
  smallint, uniqueIndex, index, bigint as mysqlBigint, primaryKey, json
} from 'drizzle-orm/mysql-core';

export const users = mysqlTable('users', {
  id: varchar('id', { length: 36 }).primaryKey(),
  oidcSub: varchar('oidc_sub', { length: 255 }).notNull().unique(),
  email: varchar('email', { length: 320 }),
  displayName: varchar('display_name', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull().$onUpdate(() => new Date())
});

export const assets = mysqlTable('assets', {
  id: varchar('id', { length: 36 }).primaryKey(),
  ownerId: varchar('owner_id', { length: 36 }).notNull(),
  objectKey: varchar('object_key', { length: 512 }).notNull().unique(),
  kind: mysqlEnum('kind', ['garment', 'template', 'result']).notNull(),
  mimeType: varchar('mime_type', { length: 100 }).notNull(),
  fileSize: bigint('file_size', { mode: 'number', unsigned: true }).notNull(),
  width: int('width', { unsigned: true }).notNull(),
  height: int('height', { unsigned: true }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, table => ({ ownerCreated: index('idx_assets_owner_created').on(table.ownerId, table.createdAt) }));

export const templates = mysqlTable('templates', {
  id: varchar('id', { length: 36 }).primaryKey(),
  ownerId: varchar('owner_id', { length: 36 }).notNull(),
  assetId: varchar('asset_id', { length: 36 }).notNull(),
  name: varchar('name', { length: 160 }).notNull(),
  description: text('description'),
  pose: mysqlEnum('pose', ['front', 'three_quarter', 'side']).notNull(),
  category: mysqlEnum('category', ['tops', 'bottoms', 'one-pieces', 'all']).default('all').notNull(),
  adultVerified: boolean('adult_verified').default(false).notNull(),
  rightsConfirmed: boolean('rights_confirmed').default(false).notNull(),
  provenance: text('provenance').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, table => ({ poseCategory: index('idx_templates_pose_category').on(table.pose, table.category) }));

export const designs = mysqlTable('designs', {
  id: varchar('id', { length: 36 }).primaryKey(),
  ownerId: varchar('owner_id', { length: 36 }).notNull(),
  name: varchar('name', { length: 160 }).notNull(),
  garmentAssetId: varchar('garment_asset_id', { length: 36 }).notNull(),
  category: mysqlEnum('category', ['tops', 'bottoms', 'one-pieces']).notNull(),
  background: mysqlEnum('background', ['keep_template']).default('keep_template').notNull(),
  status: mysqlEnum('status', ['draft', 'queued', 'processing', 'review', 'approved', 'rejected', 'failed']).default('draft').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull().$onUpdate(() => new Date())
}, table => ({ ownerCreated: index('idx_designs_owner_created').on(table.ownerId, table.createdAt) }));

export const designTemplates = mysqlTable('design_templates', {
  designId: varchar('design_id', { length: 36 }).notNull(),
  templateId: varchar('template_id', { length: 36 }).notNull(),
  position: smallint('position', { unsigned: true }).default(0).notNull()
}, table => ({ primary: primaryKey({ columns: [table.designId, table.templateId] }) }));

export const generationJobs = mysqlTable('generation_jobs', {
  id: varchar('id', { length: 36 }).primaryKey(),
  designId: varchar('design_id', { length: 36 }).notNull(),
  ownerId: varchar('owner_id', { length: 36 }).notNull(),
  idempotencyKey: varchar('idempotency_key', { length: 128 }).notNull(),
  status: mysqlEnum('status', ['queued', 'processing', 'review', 'succeeded', 'failed']).default('queued').notNull(),
  attempts: smallint('attempts', { unsigned: true }).default(0).notNull(),
  outputAssetId: varchar('output_asset_id', { length: 36 }),
  fidelityStatus: mysqlEnum('fidelity_status', ['not_checked', 'manual_review_required', 'approved_by_user', 'rejected_by_user']).default('not_checked').notNull(),
  errorCode: varchar('error_code', { length: 80 }),
  errorMessage: varchar('error_message', { length: 500 }),
  startedAt: timestamp('started_at'),
  finishedAt: timestamp('finished_at'),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, table => ({ ownerKey: uniqueIndex('uq_job_idempotency').on(table.ownerId, table.idempotencyKey), queue: index('idx_jobs_queue').on(table.status, table.createdAt) }));

export const auditLogs = mysqlTable('audit_logs', {
  id: mysqlBigint('id', { mode: 'number', unsigned: true }).autoincrement().primaryKey(),
  userId: varchar('user_id', { length: 36 }),
  action: varchar('action', { length: 100 }).notNull(),
  entityType: varchar('entity_type', { length: 80 }).notNull(),
  entityId: varchar('entity_id', { length: 80 }),
  details: json('details'),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, table => ({ userCreated: index('idx_audit_user_created').on(table.userId, table.createdAt) }));
