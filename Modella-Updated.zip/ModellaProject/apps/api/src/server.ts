import crypto from 'node:crypto';
import express, { type NextFunction, type Request, type Response } from 'express';
import session from 'express-session';
import MySQLStoreFactory from 'express-mysql-session';
import helmet from 'helmet';
import multer from 'multer';
import mysql from 'mysql2/promise';
import { drizzle } from 'drizzle-orm/mysql2';
import { eq } from 'drizzle-orm';
import * as schema from './schema.js';
import { Client as MinioClient } from 'minio';
import sharp from 'sharp';
import { rateLimit } from 'express-rate-limit';
import * as oidc from 'openid-client';
import { initTRPC } from '@trpc/server';
import { createExpressMiddleware } from '@trpc/server/adapters/express';

const required = [
  'SESSION_SECRET', 'MYSQL_PASSWORD', 'MYSQL_DATABASE', 'MYSQL_USER',
  'OIDC_ISSUER', 'OIDC_CLIENT_ID', 'OIDC_CLIENT_SECRET', 'OIDC_REDIRECT_URI',
  'APP_ORIGIN', 'MINIO_ACCESS_KEY', 'MINIO_SECRET_KEY'
] as const;
for (const key of required) {
  const value = process.env[key] ?? '';
  if (!value || /(replace-with|your-|example\.com)/i.test(value)) {
    throw new Error(`Missing or placeholder environment variable: ${key}`);
  }
}
if ((process.env.SESSION_SECRET ?? '').length < 32) {
  throw new Error('SESSION_SECRET must contain at least 32 characters.');
}
if (process.env.NODE_ENV === 'production') {
  if (process.env.TRUST_PROXY !== '1') throw new Error('TRUST_PROXY=1 is required behind the production TLS reverse proxy.');
  const publicOrigin = new URL(process.env.APP_ORIGIN!);
  const callbackUrl = new URL(process.env.OIDC_REDIRECT_URI!);
  const issuerUrl = new URL(process.env.OIDC_ISSUER!);
  if (publicOrigin.protocol !== 'https:' || callbackUrl.protocol !== 'https:' || issuerUrl.protocol !== 'https:' || callbackUrl.origin !== publicOrigin.origin) {
    throw new Error('Production APP_ORIGIN, OIDC_ISSUER and same-origin OIDC_REDIRECT_URI must use HTTPS.');
  }
  const storageHost = (process.env.MINIO_ENDPOINT ?? 'minio').toLowerCase();
  if (!['minio', 'localhost', '127.0.0.1'].includes(storageHost) && process.env.MINIO_USE_SSL !== '1') {
    throw new Error('MINIO_USE_SSL=1 is required for external MinIO deployments in production.');
  }
}

const port = Number(process.env.PORT ?? 4000);
const appOrigin = new URL(process.env.APP_ORIGIN!).origin;
const vtonUrl = (process.env.VTON_URL ?? 'http://vton-worker:8000').replace(/\/$/, '');
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST ?? 'mysql',
  port: Number(process.env.MYSQL_PORT ?? 3306),
  user: process.env.MYSQL_USER!,
  password: process.env.MYSQL_PASSWORD!,
  database: process.env.MYSQL_DATABASE!,
  waitForConnections: true,
  connectionLimit: 12,
  decimalNumbers: true,
  enableKeepAlive: true
});
// Drizzle remains the typed ORM entry point for future schema-backed queries.
const db = drizzle(pool, { schema });
void db;

const minio = new MinioClient({
  endPoint: process.env.MINIO_ENDPOINT ?? 'minio',
  port: Number(process.env.MINIO_PORT ?? 9000),
  useSSL: process.env.MINIO_USE_SSL === '1',
  accessKey: process.env.MINIO_ACCESS_KEY!,
  secretKey: process.env.MINIO_SECRET_KEY!
});
const bucket = process.env.MINIO_BUCKET ?? 'modella-private';
const MySQLStore = MySQLStoreFactory(session);

const app = express();

app.disable('x-powered-by');
if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'same-site' },
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      styleSrc: ["'self'", "'unsafe-inline'"],
      fontSrc: ["'self'", 'data:'],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: '200kb' }));
app.use(session({
  name: 'modella.sid',
  secret: process.env.SESSION_SECRET!,
  resave: false,
  saveUninitialized: false,
  store: new MySQLStore({
    host: process.env.MYSQL_HOST ?? 'mysql',
    port: Number(process.env.MYSQL_PORT ?? 3306),
    user: process.env.MYSQL_USER!,
    password: process.env.MYSQL_PASSWORD!,
    database: process.env.MYSQL_DATABASE!,
    createDatabaseTable: true,
    clearExpired: true,
    checkExpirationInterval: 15 * 60 * 1000
  }),
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/'
  }
}));

interface SessionUser { id: string; sub: string; email: string | null; name: string | null }
declare module 'express-session' {
  interface SessionData {
    user?: SessionUser;
    oauthFlow?: { verifier: string; state: string; nonce: string };
  }
}

const requireAuth = (req: Request, res: Response, next: NextFunction) =>
  req.session.user ? next() : res.status(401).json({ error: 'يلزم تسجيل الدخول للمتابعة.' });

const mutationGuard = (req: Request, res: Response, next: NextFunction) => {
  const origin = req.get('origin');
  if (origin) {
    try {
      if (new URL(origin).origin !== appOrigin) return res.status(403).json({ error: 'تم رفض الطلب لأسباب أمنية.' });
    } catch {
      return res.status(403).json({ error: 'مصدر الطلب غير صالح.' });
    }
  }
  next();
};
app.use('/api', (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  mutationGuard(req, res, next);
});

const uploadLimit = rateLimit({
  windowMs: 60_000,
  limit: 12,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'طلبات كثيرة. حاول بعد دقيقة.' }
});
const generationLimit = rateLimit({
  windowMs: 60_000,
  limit: 4,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'وصلت إلى حد طلبات التوليد المؤقت. حاول بعد دقيقة.' }
});
const memoryUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: Number(process.env.MAX_UPLOAD_MB ?? 12) * 1024 * 1024, files: 1 }
});
const allowedFormats: Record<string, string> = {
  jpeg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp'
};

let oidcConfigPromise: ReturnType<typeof oidc.discovery> | null = null;
function getOidcConfig() {
  if (!oidcConfigPromise) {
    oidcConfigPromise = oidc.discovery(
      new URL(process.env.OIDC_ISSUER!),
      process.env.OIDC_CLIENT_ID!,
      process.env.OIDC_CLIENT_SECRET!
    );
  }
  return oidcConfigPromise;
}

async function ensureBucket() {
  if (!await minio.bucketExists(bucket)) await minio.makeBucket(bucket);
}

async function inspectImage(file: Express.Multer.File) {
  let metadata: Awaited<ReturnType<ReturnType<typeof sharp>['metadata']>>;
  try {
    metadata = await sharp(file.buffer, { failOn: 'error', limitInputPixels: 80_000_000 }).metadata();
  } catch {
    throw new Error('الصورة تالفة أو تعذر فك ترميزها. اختر ملف صورة صالحاً.');
  }
  if (!metadata.format || !allowedFormats[metadata.format] || allowedFormats[metadata.format] !== file.mimetype) {
    throw new Error('صيغة الصورة الفعلية لا تطابق نوع الملف المعلن.');
  }
  if (!metadata.width || !metadata.height || metadata.width > 12000 || metadata.height > 12000) {
    throw new Error('أبعاد الصورة غير مدعومة.');
  }
  if ((metadata.pages ?? 1) > 1) throw new Error('الصور المتحركة غير مدعومة؛ استخدم صورة ثابتة.');
  const swapDimensions = [5, 6, 7, 8].includes(metadata.orientation ?? 1);
  const width = swapDimensions ? metadata.height : metadata.width;
  const height = swapDimensions ? metadata.width : metadata.height;
  if (width < 64 || height < 64) throw new Error('الصورة صغيرة جداً للمعالجة. اختر صورة أكبر.');
  if (width * height > 80_000_000) throw new Error('دقة الصورة أعلى من الحد الآمن للمعالجة.');
  try {
    // Force a full decode; metadata parsing alone does not prove the image is intact.
    await sharp(file.buffer, { failOn: 'error', limitInputPixels: 80_000_000 }).stats();
  } catch {
    throw new Error('الصورة تالفة أو تعذر فك ترميزها بالكامل. اختر ملفاً آخر.');
  }
  return { width, height, mime: allowedFormats[metadata.format] };
}

async function saveAsset(ownerId: string, file: Express.Multer.File, kind: 'garment' | 'template' | 'result') {
  const metadata = await inspectImage(file);
  const id = crypto.randomUUID();
  const ext = metadata.mime === 'image/jpeg' ? 'jpg' : metadata.mime.split('/')[1];
  const objectKey = `${ownerId}/${kind}/${id}.${ext}`;
  await minio.putObject(bucket, objectKey, file.buffer, file.size, {
    'Content-Type': metadata.mime,
    'Cache-Control': 'private, no-store'
  });
  try {
    await pool.execute(
      'INSERT INTO assets (id,owner_id,object_key,kind,mime_type,file_size,width,height) VALUES (?,?,?,?,?,?,?,?)',
      [id, ownerId, objectKey, kind, metadata.mime, file.size, metadata.width, metadata.height]
    );
  } catch (error) {
    await minio.removeObject(bucket, objectKey).catch(() => undefined);
    throw error;
  }
  return { id, kind, mimeType: metadata.mime, fileSize: file.size, width: metadata.width, height: metadata.height };
}

async function audit(userId: string | null, action: string, type: string, id: string | null, details: Record<string, unknown> = {}) {
  try {
    await pool.execute(
      'INSERT INTO audit_logs (user_id,action,entity_type,entity_id,details) VALUES (?,?,?,?,?)',
      [userId, action, type, id, JSON.stringify(details)]
    );
  } catch (error) {
    console.error('audit_write_failed', error instanceof Error ? error.name : 'unknown');
  }
}

async function getVtonHealth(): Promise<{ ready: boolean; provider?: string; reason?: string; model?: string }> {
  try {
    const response = await fetch(`${vtonUrl}/health`, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) return { ready: false, reason: 'تعذر التحقق من محرك الصور.' };
    const body = await response.json() as { ready?: boolean; provider?: string; reason?: string; model?: string };
    return { ready: body.ready === true, provider: body.provider, reason: body.reason, model: body.model };
  } catch {
    return { ready: false, reason: 'خدمة الذكاء الاصطناعي غير متصلة حالياً.' };
  }
}

app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    await minio.bucketExists(bucket);
    res.json({ ok: true, service: 'modella-api', storage: 'ready' });
  } catch {
    res.status(503).json({ ok: false, service: 'modella-api', error: 'dependency_unavailable' });
  }
});

app.get('/api/system/status', async (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const vton = await getVtonHealth();
  res.json({
    app: 'ready',
    authentication: 'oidc',
    storage: 'private',
    generation: vton.ready ? 'ready' : 'unavailable',
    vton: {
      ready: vton.ready,
      provider: vton.provider ?? null,
      model: vton.model ?? null,
      message: vton.ready ? 'محرك التوليد جاهز.' : (vton.reason ?? 'محرك التوليد غير مهيأ.')
    }
  });
});

// tRPC is the typed application-RPC surface; REST routes below are retained for uploads,
// streaming assets, and browser-friendly download endpoints.
const trpc = initTRPC.context<{ req: Request }>().create();
const trpcRouter = trpc.router({
  systemStatus: trpc.procedure.query(async () => {
    const vton = await getVtonHealth();
    return {
      app: 'ready',
      authentication: 'oidc',
      storage: 'private',
      generation: vton.ready ? 'ready' : 'unavailable',
      vton: {
        ready: vton.ready,
        provider: vton.provider ?? null,
        model: vton.model ?? null,
        message: vton.ready ? 'محرك التوليد جاهز.' : (vton.reason ?? 'محرك التوليد غير مهيأ.')
      }
    };
  }),
  currentUser: trpc.procedure.query(({ ctx }) => ({
    authenticated: Boolean(ctx.req.session.user),
    user: ctx.req.session.user ? {
      id: ctx.req.session.user.id,
      email: ctx.req.session.user.email,
      name: ctx.req.session.user.name
    } : null
  }))
});
export type AppRouter = typeof trpcRouter;
app.use('/api/trpc', (_req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
app.use('/api/trpc', createExpressMiddleware({
  router: trpcRouter,
  createContext: ({ req }) => ({ req })
}));

app.get('/api/auth/me', async (req, res, next) => {
  try {
    if (!req.session.user) return res.json({ authenticated: false });
    const rows = await db.select({
      id: schema.users.id,
      email: schema.users.email,
      name: schema.users.displayName
    }).from(schema.users).where(eq(schema.users.id, req.session.user.id)).limit(1);
    if (!rows.length) {
      req.session.destroy(() => undefined);
      return res.json({ authenticated: false });
    }
    res.json({ authenticated: true, user: rows[0] });
  } catch (error) { next(error); }
});

app.get('/api/auth/login', async (req, res, next) => {
  try {
    if (req.session.user) return res.redirect(appOrigin);
    const config = await getOidcConfig();
    const verifier = oidc.randomPKCECodeVerifier();
    const challenge = await oidc.calculatePKCECodeChallenge(verifier);
    const state = oidc.randomState();
    const nonce = oidc.randomNonce();
    req.session.oauthFlow = { verifier, state, nonce };
    const url = oidc.buildAuthorizationUrl(config, {
      redirect_uri: process.env.OIDC_REDIRECT_URI!,
      scope: 'openid profile email',
      code_challenge: challenge,
      code_challenge_method: 'S256',
      state,
      nonce
    });
    req.session.save(error => error ? next(error) : res.redirect(url.href));
  } catch (error) { next(error); }
});

app.get('/api/auth/callback', async (req, res, next) => {
  try {
    const flow = req.session.oauthFlow;
    if (!flow) return res.status(400).send('انتهت جلسة تسجيل الدخول. ارجع وحاول مجدداً.');
    const config = await getOidcConfig();
    const currentUrl = new URL(`${process.env.OIDC_REDIRECT_URI!}${req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : ''}`);
    const tokens = await oidc.authorizationCodeGrant(config, currentUrl, {
      pkceCodeVerifier: flow.verifier,
      expectedState: flow.state,
      expectedNonce: flow.nonce
    });
    const claims = tokens.claims();
    if (!claims?.sub) throw new Error('OIDC response missing subject');
    const userInfo = tokens.access_token
      ? await oidc.fetchUserInfo(config, tokens.access_token, claims.sub)
      : null;
    const email = userInfo && typeof userInfo.email === 'string' ? userInfo.email : null;
    const name = userInfo && typeof userInfo.name === 'string' ? userInfo.name : null;
    const id = crypto.randomUUID();
    await pool.execute(
      'INSERT INTO users (id,oidc_sub,email,display_name) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE email=VALUES(email),display_name=VALUES(display_name)',
      [id, claims.sub, email, name]
    );
    const [rows] = await pool.execute<any[]>('SELECT id FROM users WHERE oidc_sub=?', [claims.sub]);
    if (!rows.length) throw new Error('User account could not be persisted');
    req.session.regenerate(error => {
      if (error) return next(error);
      req.session.user = { id: rows[0].id, sub: claims.sub!, email, name };
      req.session.save(saveError => saveError ? next(saveError) : res.redirect(appOrigin));
    });
  } catch (error) { next(error); }
});

app.post('/api/auth/logout', requireAuth, (req, res) => {
  req.session.destroy(error => {
    if (error) return res.status(500).json({ error: 'تعذر إنهاء الجلسة.' });
    res.clearCookie('modella.sid', { path: '/', sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
    res.json({ ok: true });
  });
});

app.get('/api/templates', requireAuth, async (_req, res, next) => {
  try {
    const [rows] = await pool.execute<any[]>(
      `SELECT t.id,t.name,t.description,t.pose,t.category,t.asset_id AS assetId,a.width,a.height,a.mime_type AS mimeType
       FROM templates t JOIN assets a ON a.id=t.asset_id
       WHERE t.adult_verified=1 AND t.rights_confirmed=1 ORDER BY t.created_at DESC`
    );
    res.json({ items: rows.map(row => ({ ...row, imageUrl: `/api/modella/assets/${row.assetId}` })) });
  } catch (error) { next(error); }
});

app.post('/api/modella/assets', requireAuth, uploadLimit, memoryUpload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'اختر صورة أولاً.' });
    const asset = await saveAsset(req.session.user!.id, req.file, 'garment');
    await audit(req.session.user!.id, 'asset.upload', 'asset', asset.id);
    res.status(201).json({ asset });
  } catch (error) {
    if (error instanceof Error && /صيغة|أبعاد|دقة الصورة|الصورة تالفة|الصورة صغيرة/.test(error.message)) return res.status(400).json({ error: error.message });
    next(error);
  }
});

app.get('/api/modella/assets/:key', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.execute<any[]>(
      `SELECT a.object_key,a.mime_type,a.file_size FROM assets a
       WHERE a.id=? AND (a.owner_id=? OR EXISTS (
         SELECT 1 FROM templates t WHERE t.asset_id=a.id AND t.adult_verified=1 AND t.rights_confirmed=1
       )) LIMIT 1`,
      [req.params.key, req.session.user!.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'الملف غير موجود أو لا تملك صلاحية الوصول إليه.' });
    const stream = await minio.getObject(bucket, rows[0].object_key);
    res.setHeader('Content-Type', rows[0].mime_type);
    res.setHeader('Content-Length', String(rows[0].file_size));
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    stream.on('error', next);
    stream.pipe(res);
  } catch (error) { next(error); }
});

const adminSubjects = new Set((process.env.ADMIN_SUBJECTS ?? '').split(',').map(value => value.trim()).filter(Boolean));
app.post('/api/admin/templates', requireAuth, uploadLimit, memoryUpload.single('file'), async (req, res, next) => {
  try {
    if (!adminSubjects.has(req.session.user!.sub)) return res.status(403).json({ error: 'هذه العملية متاحة للمسؤول فقط.' });
    if (req.body.adultVerified !== 'true' || req.body.rightsConfirmed !== 'true' || typeof req.body.provenance !== 'string' || req.body.provenance.trim().length < 8) {
      return res.status(400).json({ error: 'يجب تأكيد أن العارضة بالغة وامتلاك الحقوق وتسجيل مصدر الصورة.' });
    }
    if (!req.file) return res.status(400).json({ error: 'أرفق صورة القالب.' });
    if (!['front', 'three_quarter', 'side'].includes(req.body.pose) || !['tops', 'bottoms', 'one-pieces', 'all'].includes(req.body.category)) {
      return res.status(400).json({ error: 'بيانات القالب غير صالحة.' });
    }
    const asset = await saveAsset(req.session.user!.id, req.file, 'template');
    const id = crypto.randomUUID();
    try {
      await pool.execute(
        'INSERT INTO templates (id,owner_id,asset_id,name,description,pose,category,adult_verified,rights_confirmed,provenance) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [id, req.session.user!.id, asset.id, String(req.body.name ?? 'عارضة').slice(0, 160), req.body.description ?? null, req.body.pose, req.body.category, 1, 1, req.body.provenance.trim()]
      );
    } catch (error) {
      let orphanKey: string | null = null;
      try {
        const [assetRows] = await pool.execute<any[]>('SELECT object_key FROM assets WHERE id=?', [asset.id]);
        orphanKey = assetRows[0]?.object_key ?? null;
      } catch { /* Best-effort cleanup must not hide the original database error. */ }
      await pool.execute('DELETE FROM assets WHERE id=?', [asset.id]).catch(() => undefined);
      if (orphanKey) await minio.removeObject(bucket, orphanKey).catch(() => undefined);
      throw error;
    }
    await audit(req.session.user!.id, 'template.create', 'template', id);
    res.status(201).json({ id });
  } catch (error) { next(error); }
});

app.post('/api/designs', requireAuth, async (req, res, next) => {
  const connection = await pool.getConnection();
  try {
    const { assetId, templateIds, category, name } = req.body as { assetId?: string; templateIds?: string[]; category?: string; name?: string };
    if (!assetId || !Array.isArray(templateIds) || templateIds.length < 1 || templateIds.length > 2 || !['tops', 'bottoms', 'one-pieces'].includes(category ?? '')) {
      return res.status(400).json({ error: 'أكمل صورة القطعة والعارضة والفئة أولاً.' });
    }
    if (templateIds.some(id => typeof id !== 'string' || id.length > 64) || new Set(templateIds).size !== templateIds.length) {
      return res.status(400).json({ error: 'اختيار قوالب العارضات غير صالح.' });
    }
    await connection.beginTransaction();
    const [assetRows] = await connection.execute<any[]>(
      "SELECT id FROM assets WHERE id=? AND owner_id=? AND kind='garment' FOR UPDATE",
      [assetId, req.session.user!.id]
    );
    if (!assetRows.length) {
      await connection.rollback();
      return res.status(404).json({ error: 'صورة الملابس غير موجودة.' });
    }
    const [templateRows] = await connection.execute<any[]>(
      `SELECT id,pose,category FROM templates WHERE id IN (${templateIds.map(() => '?').join(',')}) AND adult_verified=1 AND rights_confirmed=1`,
      templateIds
    );
    if (templateRows.length !== templateIds.length) {
      await connection.rollback();
      return res.status(400).json({ error: 'أحد قوالب العارضات غير متاح.' });
    }
    if (templateRows.some(template => template.category !== 'all' && template.category !== category)) {
      await connection.rollback();
      return res.status(400).json({ error: 'فئة الملابس لا تتوافق مع أحد القوالب.' });
    }
    if (templateRows.length === 2 && new Set(templateRows.map(template => template.pose)).size === 1) {
      await connection.rollback();
      return res.status(400).json({ error: 'اختر وضعيتين مختلفتين لإنتاج لوحتين مستقلتين.' });
    }
    const id = crypto.randomUUID();
    await connection.execute(
      "INSERT INTO designs (id,owner_id,name,garment_asset_id,category,status) VALUES (?,?,?,?,?,'draft')",
      [id, req.session.user!.id, String(name ?? 'تصميم جديد').slice(0, 160), assetId, category]
    );
    for (let index = 0; index < templateIds.length; index++) {
      await connection.execute('INSERT INTO design_templates (design_id,template_id,position) VALUES (?,?,?)', [id, templateIds[index], index]);
    }
    await connection.commit();
    await audit(req.session.user!.id, 'design.create', 'design', id);
    res.status(201).json({ id, status: 'draft' });
  } catch (error) {
    await connection.rollback().catch(() => undefined);
    next(error);
  } finally { connection.release(); }
});

app.get('/api/designs', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.execute<any[]>(
      `SELECT d.id,d.name,d.category,d.status,d.created_at AS createdAt,
              a.id AS garmentAssetId,j.id AS jobId,j.status AS jobStatus,
              j.fidelity_status AS fidelityStatus,j.error_code AS errorCode,
              j.error_message AS errorMessage,j.output_asset_id AS outputAssetId,
              j.created_at AS jobCreatedAt
       FROM designs d JOIN assets a ON a.id=d.garment_asset_id
       LEFT JOIN generation_jobs j ON j.id=(
         SELECT j2.id FROM generation_jobs j2 WHERE j2.design_id=d.id ORDER BY j2.created_at DESC,j2.id DESC LIMIT 1
       )
       WHERE d.owner_id=? ORDER BY d.created_at DESC LIMIT 100`,
      [req.session.user!.id]
    );
    res.json({ items: rows.map(row => ({
      ...row,
      garmentUrl: `/api/modella/assets/${row.garmentAssetId}`,
      resultUrl: row.outputAssetId ? `/api/modella/assets/${row.outputAssetId}` : null
    })) });
  } catch (error) { next(error); }
});

app.get('/api/designs/:id', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.execute<any[]>(
      `SELECT d.id,d.name,d.category,d.status,d.created_at AS createdAt,
              d.garment_asset_id AS garmentAssetId,a.width AS garmentWidth,a.height AS garmentHeight, a.file_size AS garmentSize
       FROM designs d JOIN assets a ON a.id=d.garment_asset_id
       WHERE d.id=? AND d.owner_id=?`,
      [req.params.id, req.session.user!.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'التصميم غير موجود.' });
    const [templateRows] = await pool.execute<any[]>(
      'SELECT t.id,t.name,t.pose,t.category FROM design_templates dt JOIN templates t ON t.id=dt.template_id WHERE dt.design_id=? ORDER BY dt.position',
      [req.params.id]
    );
    const [jobs] = await pool.execute<any[]>(
      'SELECT id,status,fidelity_status AS fidelityStatus,error_code AS errorCode,error_message AS errorMessage,output_asset_id AS outputAssetId,created_at AS createdAt FROM generation_jobs WHERE design_id=? AND owner_id=? ORDER BY created_at DESC',
      [req.params.id, req.session.user!.id]
    );
    res.json({
      design: { ...rows[0], garmentUrl: `/api/modella/assets/${rows[0].garmentAssetId}` },
      templates: templateRows,
      jobs: jobs.map(job => ({ ...job, resultUrl: job.outputAssetId ? `/api/modella/assets/${job.outputAssetId}` : null }))
    });
  } catch (error) { next(error); }
});

app.post('/api/designs/:id/generate', requireAuth, generationLimit, async (req, res, next) => {
  const ownerId = req.session.user!.id;
  const key = String(req.get('idempotency-key') ?? crypto.randomUUID()).trim().slice(0, 128);
  try {
    const [existingBefore] = await pool.execute<any[]>(
      'SELECT id,design_id,status FROM generation_jobs WHERE owner_id=? AND idempotency_key=?',
      [ownerId, key]
    );
    if (existingBefore.length) {
      if (existingBefore[0].design_id !== req.params.id) return res.status(409).json({ error: 'مفتاح الطلب مستخدم لتصميم آخر.' });
      return res.status(200).json({ jobId: existingBefore[0].id, status: existingBefore[0].status, reused: true });
    }

    const vton = await getVtonHealth();
    if (!vton.ready) return res.status(503).json({ error: vton.reason ?? 'محرك VTON غير جاهز. لم تتم إضافة طلب توليد.' });

    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      const [designRows] = await connection.execute<any[]>(
        'SELECT id,status FROM designs WHERE id=? AND owner_id=? FOR UPDATE',
        [req.params.id, ownerId]
      );
      if (!designRows.length) {
        await connection.rollback();
        return res.status(404).json({ error: 'التصميم غير موجود.' });
      }
      const [existing] = await connection.execute<any[]>(
        'SELECT id,design_id,status FROM generation_jobs WHERE owner_id=? AND idempotency_key=? FOR UPDATE',
        [ownerId, key]
      );
      if (existing.length) {
        await connection.rollback();
        if (existing[0].design_id !== req.params.id) return res.status(409).json({ error: 'مفتاح الطلب مستخدم لتصميم آخر.' });
        return res.status(200).json({ jobId: existing[0].id, status: existing[0].status, reused: true });
      }
      if (['queued', 'processing', 'review'].includes(designRows[0].status)) {
        await connection.rollback();
        return res.status(409).json({ error: 'يوجد طلب توليد قائم لهذا التصميم. أكمل مراجعته أولاً.' });
      }
      const [templatesForDesign] = await connection.execute<any[]>(
        `SELECT dt.template_id FROM design_templates dt JOIN templates t ON t.id=dt.template_id
         WHERE dt.design_id=? AND t.adult_verified=1 AND t.rights_confirmed=1 ORDER BY dt.position`,
        [req.params.id]
      );
      if (!templatesForDesign.length) {
        await connection.rollback();
        return res.status(400).json({ error: 'لا يوجد قالب عارضة موثق وصالح للتصميم.' });
      }
      const jobId = crypto.randomUUID();
      await connection.execute(
        "INSERT INTO generation_jobs (id,design_id,owner_id,idempotency_key,status) VALUES (?,?,?,?,'queued')",
        [jobId, req.params.id, ownerId, key]
      );
      await connection.execute("UPDATE designs SET status='queued' WHERE id=? AND owner_id=?", [req.params.id, ownerId]);
      await connection.commit();
      await audit(ownerId, 'generation.enqueue', 'job', jobId, { templateCount: templatesForDesign.length });
      res.status(202).json({ jobId, status: 'queued', message: 'أضيف طلبك إلى قائمة الانتظار.' });
    } catch (error) {
      await connection.rollback().catch(() => undefined);
      throw error;
    } finally { connection.release(); }
  } catch (error) { next(error); }
});

app.get('/api/jobs/:id', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.execute<any[]>(
      `SELECT j.id,j.design_id AS designId,j.status,j.fidelity_status AS fidelityStatus,
              j.error_code AS errorCode,j.error_message AS errorMessage,
              j.output_asset_id AS outputAssetId,j.created_at AS createdAt,
              j.started_at AS startedAt,j.finished_at AS finishedAt
       FROM generation_jobs j WHERE j.id=? AND j.owner_id=? LIMIT 1`,
      [req.params.id, req.session.user!.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'عملية التوليد غير موجودة.' });
    const row = rows[0];
    res.json({
      job: {
        ...row,
        resultUrl: row.outputAssetId ? `/api/modella/assets/${row.outputAssetId}` : null,
        reviewRequired: row.status === 'review'
      }
    });
  } catch (error) { next(error); }
});

app.post('/api/jobs/:id/approve', requireAuth, async (req, res, next) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [rows] = await connection.execute<any[]>(
      'SELECT id,design_id,output_asset_id,status FROM generation_jobs WHERE id=? AND owner_id=? FOR UPDATE',
      [req.params.id, req.session.user!.id]
    );
    if (!rows.length) { await connection.rollback(); return res.status(404).json({ error: 'العملية غير موجودة.' }); }
    if (rows[0].status !== 'review' || !rows[0].output_asset_id) { await connection.rollback(); return res.status(409).json({ error: 'لا توجد نتيجة جاهزة للمراجعة.' }); }
    await connection.execute("UPDATE generation_jobs SET status='succeeded',fidelity_status='approved_by_user',finished_at=NOW() WHERE id=? AND owner_id=? AND status='review'", [req.params.id, req.session.user!.id]);
    await connection.execute("UPDATE designs SET status='approved' WHERE id=? AND owner_id=?", [rows[0].design_id, req.session.user!.id]);
    await connection.commit();
    await audit(req.session.user!.id, 'generation.approve', 'job', req.params.id);
    res.json({ ok: true, status: 'succeeded' });
  } catch (error) { await connection.rollback().catch(() => undefined); next(error); }
  finally { connection.release(); }
});

app.post('/api/jobs/:id/reject', requireAuth, async (req, res, next) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [rows] = await connection.execute<any[]>(
      'SELECT id,design_id,status FROM generation_jobs WHERE id=? AND owner_id=? FOR UPDATE',
      [req.params.id, req.session.user!.id]
    );
    if (!rows.length) { await connection.rollback(); return res.status(404).json({ error: 'العملية غير موجودة.' }); }
    if (rows[0].status !== 'review') { await connection.rollback(); return res.status(409).json({ error: 'العملية ليست بانتظار المراجعة.' }); }
    await connection.execute(
      "UPDATE generation_jobs SET status='failed',fidelity_status='rejected_by_user',error_code='USER_REJECTED',error_message='رفض المستخدم النتيجة أثناء المراجعة',finished_at=NOW() WHERE id=? AND owner_id=? AND status='review'",
      [req.params.id, req.session.user!.id]
    );
    await connection.execute("UPDATE designs SET status='rejected' WHERE id=? AND owner_id=?", [rows[0].design_id, req.session.user!.id]);
    await connection.commit();
    await audit(req.session.user!.id, 'generation.reject', 'job', req.params.id);
    res.json({ ok: true, status: 'rejected' });
  } catch (error) { await connection.rollback().catch(() => undefined); next(error); }
  finally { connection.release(); }
});

app.delete('/api/designs/:id', requireAuth, async (req, res, next) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [designRows] = await connection.execute<any[]>(
      'SELECT id,garment_asset_id FROM designs WHERE id=? AND owner_id=? FOR UPDATE', [req.params.id, req.session.user!.id]
    );
    if (!designRows.length) {
      await connection.rollback();
      return res.status(404).json({ error: 'التصميم غير موجود.' });
    }
    const [outputRows] = await connection.execute<any[]>(
      'SELECT output_asset_id AS id FROM generation_jobs WHERE design_id=? AND owner_id=? AND output_asset_id IS NOT NULL',
      [req.params.id, req.session.user!.id]
    );
    const candidateIds = [...new Set([designRows[0].garment_asset_id, ...outputRows.map(row => row.id)])] as string[];
    await connection.execute('DELETE FROM designs WHERE id=? AND owner_id=?', [req.params.id, req.session.user!.id]);
    const [referenced] = await connection.query<any[]>(
      `SELECT a.id,a.object_key FROM assets a
       WHERE a.id IN (${candidateIds.map(() => '?').join(',')})
       AND NOT EXISTS (SELECT 1 FROM designs d WHERE d.garment_asset_id=a.id)
       AND NOT EXISTS (SELECT 1 FROM templates t WHERE t.asset_id=a.id)
       AND NOT EXISTS (SELECT 1 FROM generation_jobs j WHERE j.output_asset_id=a.id)`,
      candidateIds
    );
    for (const asset of referenced) await connection.execute('DELETE FROM assets WHERE id=? AND owner_id=?', [asset.id, req.session.user!.id]);
    await connection.commit();
    for (const asset of referenced) await minio.removeObject(bucket, asset.object_key).catch(() => undefined);
    await audit(req.session.user!.id, 'design.delete', 'design', req.params.id);
    res.json({ ok: true });
  } catch (error) {
    await connection.rollback().catch(() => undefined);
    next(error);
  } finally { connection.release(); }
});

app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  const message = err instanceof Error ? err.message : 'unknown_error';
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `حجم الصورة أكبر من الحد (${process.env.MAX_UPLOAD_MB ?? 12}MB).` });
    return res.status(400).json({ error: 'طلب رفع الصورة غير صالح. أرسل ملفاً واحداً فقط.' });
  }
  if (message.includes('File too large')) return res.status(413).json({ error: `حجم الصورة أكبر من الحد (${process.env.MAX_UPLOAD_MB ?? 12}MB).` });
  if (/صيغة الصورة|أبعاد الصورة|دقة الصورة|الصورة تالفة|الصورة صغيرة/.test(message)) return res.status(400).json({ error: message });
  console.error('api_request_failed', err instanceof Error ? err.name : 'unknown');
  res.status(500).json({ error: 'حدث خطأ داخلي. لم يتم اعتماد العملية كنجاح.' });
});

async function waitForDependencies() {
  let lastError: unknown;
  for (let attempt = 1; attempt <= 30; attempt++) {
    try {
      await pool.query('SELECT 1');
      await ensureBucket();
      return;
    } catch (error) {
      lastError = error;
      await new Promise(resolve => setTimeout(resolve, Math.min(1000 + attempt * 500, 5000)));
    }
  }
  throw lastError instanceof Error ? lastError : new Error('Dependencies did not become ready.');
}

async function main() {
  await waitForDependencies();
  app.listen(port, '0.0.0.0', () => console.log(`Modella API listening on ${port}`));
}
main().catch(error => {
  console.error('startup_failed', error instanceof Error ? error.message : 'unknown');
  process.exit(1);
});
