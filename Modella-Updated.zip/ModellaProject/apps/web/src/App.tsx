import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDownToLine, ArrowLeft, ArrowRight, Check, CheckCircle2, ChevronDown,
  CircleAlert, Clock3, CloudUpload, Database, ExternalLink, FileImage,
  FolderOpen, ImagePlus, Images, LoaderCircle, LogIn, LogOut, Menu, RefreshCw,
  ShieldCheck, Shirt, Sparkles, Trash2, UploadCloud, UserRound, WandSparkles,
  X
} from 'lucide-react';

type User = { id: string; email: string | null; name: string | null };
type Template = {
  id: string; name: string; description: string | null;
  pose: 'front' | 'three_quarter' | 'side'; category: string;
  imageUrl: string; width: number; height: number;
};
type ArchiveItem = {
  id: string; name: string; category: string; status: string;
  createdAt: string; garmentUrl: string; resultUrl: string | null;
  jobId: string | null; jobStatus: string | null;
  fidelityStatus: string | null; errorMessage: string | null;
};
type Job = {
  id: string; designId: string; status: string; fidelityStatus: string;
  errorCode: string | null; errorMessage: string | null;
  resultUrl: string | null; reviewRequired: boolean;
};
type SystemStatus = {
  generation: string;
  vton: { ready: boolean; provider: string | null; model: string | null; message: string };
};

const categoryOptions = [
  { value: 'tops', label: 'قطعة علوية', sub: 'قميص، بلوزة، جاكيت' },
  { value: 'bottoms', label: 'قطعة سفلية', sub: 'بنطال، تنورة، شورت' },
  { value: 'one-pieces', label: 'قطعة كاملة', sub: 'فستان، جمبسوت' }
];
const poseLabels: Record<string, string> = { front: 'أمامية', three_quarter: 'ثلاثة أرباع', side: 'جانبية' };
const statusLabels: Record<string, string> = {
  draft: 'مسودة', queued: 'في قائمة الانتظار', processing: 'جارٍ التوليد',
  review: 'بانتظار مراجعتك', approved: 'معتمد', succeeded: 'مكتمل',
  rejected: 'مرفوض', failed: 'تعذر التوليد'
};

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(path, { credentials: 'same-origin', ...options });
  const contentType = response.headers.get('content-type') || '';
  const body = contentType.includes('application/json') ? await response.json() : null;
  if (!response.ok) throw new Error(body?.error || `تعذر تنفيذ الطلب (${response.status}).`);
  return body as T;
}

function formatDate(value: string) {
  try { return new Intl.DateTimeFormat('ar', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)); }
  catch { return value; }
}

function statusTone(status: string) {
  if (['approved', 'succeeded'].includes(status)) return 'success';
  if (['failed', 'rejected'].includes(status)) return 'danger';
  if (['queued', 'processing', 'review'].includes(status)) return 'working';
  return 'neutral';
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [system, setSystem] = useState<SystemStatus | null>(null);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [archive, setArchive] = useState<ArchiveItem[]>([]);
  const [activeTab, setActiveTab] = useState<'studio' | 'archive'>('studio');
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [imageInfo, setImageInfo] = useState<{ width: number; height: number; size: string } | null>(null);
  const [assetId, setAssetId] = useState('');
  const [category, setCategory] = useState('tops');
  const [selectedTemplates, setSelectedTemplates] = useState<string[]>([]);
  const [designId, setDesignId] = useState('');
  const [job, setJob] = useState<Job | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [messageKind, setMessageKind] = useState<'info' | 'error' | 'success'>('info');
  const [archiveLoading, setArchiveLoading] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [zoomImage, setZoomImage] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  const selectedTemplateObjects = useMemo(
    () => selectedTemplates.map(id => templates.find(template => template.id === id)).filter(Boolean) as Template[],
    [selectedTemplates, templates]
  );

  const notify = useCallback((text: string, kind: 'info' | 'error' | 'success' = 'info') => {
    setMessage(text);
    setMessageKind(kind);
  }, []);

  const loadArchive = useCallback(async () => {
    if (!user) return;
    setArchiveLoading(true);
    try {
      const result = await request<{ items: ArchiveItem[] }>('/api/designs');
      setArchive(result.items);
    } catch (error) {
      notify(error instanceof Error ? error.message : 'تعذر تحميل الأرشيف.', 'error');
    } finally { setArchiveLoading(false); }
  }, [user, notify]);

  useEffect(() => {
    let active = true;
    Promise.all([
      request<{ authenticated: boolean; user?: User }>('/api/auth/me'),
      request<{ result: { data: { json: SystemStatus } } }>('/api/trpc/systemStatus')
    ]).then(([auth, status]) => {
      if (!active) return;
      setUser(auth.authenticated ? auth.user ?? null : null);
      setSystem(status.result.data.json);
    }).catch(() => {
      if (active) notify('تعذر الاتصال بالخادم. تحقق من تشغيل خدمات Modella.', 'error');
    }).finally(() => { if (active) setAuthLoading(false); });
    return () => { active = false; };
  }, [notify]);

  useEffect(() => {
    if (!user) return;
    let active = true;
    Promise.all([
      request<{ items: Template[] }>('/api/templates'),
      request<{ items: ArchiveItem[] }>('/api/designs')
    ]).then(([templateResult, archiveResult]) => {
      if (!active) return;
      setTemplates(templateResult.items);
      setArchive(archiveResult.items);
    }).catch(error => {
      if (active) notify(error instanceof Error ? error.message : 'تعذر تحميل بيانات مساحة العمل.', 'error');
    });
    return () => { active = false; };
  }, [user, notify]);

  useEffect(() => {
    let active = true;
    let timer: number | undefined;
    const refresh = async () => {
      try {
        const status = await request<{ result: { data: { json: SystemStatus } } }>('/api/trpc/systemStatus', { cache: 'no-store' });
        if (active) setSystem(status.result.data.json);
      } catch {
        // The initial connection banner already handles outages; retry without blocking the UI.
      }
      if (active) timer = window.setTimeout(refresh, 15000);
    };
    timer = window.setTimeout(refresh, 15000);
    return () => { active = false; if (timer) window.clearTimeout(timer); };
  }, []);

  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  useEffect(() => {
    if (!zoomImage) return;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') setZoomImage(null); };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [zoomImage]);

  useEffect(() => {
    if (!job || !['queued', 'processing'].includes(job.status)) return;
    let cancelled = false;
    let timer: number | undefined;
    const poll = async () => {
      try {
        const result = await request<{ job: Job }>(`/api/jobs/${job.id}`);
        if (cancelled) return;
        setJob(result.job);
        if (result.job.status === 'review') {
          notify('اكتمل التوليد. راجع الصورة وقارنها بالقطعة الأصلية قبل اعتمادها.', 'success');
          void loadArchive();
          return;
        }
        if (result.job.status === 'failed') {
          notify(result.job.errorMessage || 'تعذر إكمال التوليد. لم يتم اعتماد نتيجة.', 'error');
          void loadArchive();
          return;
        }
      } catch (error) {
        if (!cancelled) notify(error instanceof Error ? error.message : 'تعذر متابعة حالة المهمة.', 'error');
      }
      if (!cancelled) timer = window.setTimeout(poll, 3000);
    };
    timer = window.setTimeout(poll, 1500);
    return () => { cancelled = true; if (timer) window.clearTimeout(timer); };
  }, [job?.id, job?.status, loadArchive, notify]);

  async function chooseFile(nextFile?: File) {
    if (!nextFile) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(nextFile.type)) {
      notify('صيغة غير مدعومة. استخدم JPG أو PNG أو WebP.', 'error');
      return;
    }
    if (nextFile.size > 12 * 1024 * 1024) {
      notify('حجم الصورة أكبر من 12 ميغابايت.', 'error');
      return;
    }
    let nextUrl = '';
    try {
      const bitmap = await createImageBitmap(nextFile, { imageOrientation: 'from-image' });
      if (bitmap.width < 64 || bitmap.height < 64) {
        bitmap.close();
        throw new Error('الصورة صغيرة جداً للمعالجة. اختر صورة أوضح وأكبر.');
      }
      if (bitmap.width > 12000 || bitmap.height > 12000 || bitmap.width * bitmap.height > 80_000_000) {
        bitmap.close();
        throw new Error('أبعاد الصورة أعلى من الحد المدعوم.');
      }
      const originalWidth = bitmap.width;
      const originalHeight = bitmap.height;
      const canvas = document.createElement('canvas');
      const scale = Math.min(1, 1800 / Math.max(bitmap.width, bitmap.height));
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      const context = canvas.getContext('2d');
      if (!context) throw new Error('تعذر إنشاء معاينة الصورة على Canvas.');
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close();
      const blob = await new Promise<Blob>((resolve, reject) => {
        canvas.toBlob(result => result ? resolve(result) : reject(new Error('تعذر إنشاء المعاينة.')), 'image/jpeg', 0.9);
      });
      nextUrl = URL.createObjectURL(blob);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      setPreviewUrl(nextUrl);
      setFile(nextFile); // Preserve and upload the original bytes, not the compressed preview.
      setAssetId('');
      setDesignId('');
      setJob(null);
      setImageInfo({ width: originalWidth, height: originalHeight, size: `${(nextFile.size / 1024 / 1024).toFixed(2)} MB` });
      notify('تم فك الصورة ومعاينتها محلياً. لم يتم رفع الملف بعد.', 'success');
    } catch (error) {
      if (nextUrl) URL.revokeObjectURL(nextUrl);
      notify(error instanceof Error ? error.message : 'تعذر قراءة الصورة أو أنها تالفة.', 'error');
    }
  }

  function clearFile() {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(''); setFile(null); setImageInfo(null); setAssetId(''); setDesignId(''); setJob(null);
    if (fileInput.current) fileInput.current.value = '';
  }

  function toggleTemplate(id: string) {
    setSelectedTemplates(current => {
      if (current.includes(id)) { setDesignId(''); setJob(null); return current.filter(value => value !== id); }
      if (current.length >= 2) {
        notify('يمكن اختيار عارضة واحدة أو مرجعين لوضعيتين مختلفتين فقط.', 'error');
        return current;
      }
      const selected = templates.find(template => template.id === id);
      if (selected && selected.category !== 'all' && selected.category !== category) {
        notify('هذا القالب غير مخصص لفئة الملابس المختارة.', 'error');
        return current;
      }
      if (selected && current.length === 1) {
        const first = templates.find(template => template.id === current[0]);
        if (first?.pose === selected.pose) {
          notify('اختر وضعية مختلفة حتى تكون اللوحتان مرجعين مستقلين.', 'error');
          return current;
        }
      }
      setDesignId(''); setJob(null);
      return [...current, id];
    });
  }

  async function startGeneration() {
    if (!user) return notify('سجّل الدخول أولاً.', 'error');
    if ((!file && !assetId) || !selectedTemplates.length) return notify('ارفع صورة القطعة واختر عارضة واحدة على الأقل.', 'error');
    if (!system?.vton.ready) return notify(system?.vton.message || 'محرك التوليد غير جاهز على الخادم.', 'error');
    setBusy(true); setJob(null);
    try {
      let currentAssetId = assetId;
      if (!currentAssetId) {
        if (!file) throw new Error('اختر صورة القطعة مجدداً قبل رفعها.');
        notify('جارٍ رفع الصورة الأصلية إلى التخزين الخاص…');
        const form = new FormData(); form.append('file', file);
        const upload = await request<{ asset: { id: string } }>('/api/modella/assets', { method: 'POST', body: form });
        currentAssetId = upload.asset.id;
        setAssetId(currentAssetId);
      }
      let currentDesignId = designId;
      if (!currentDesignId) {
        notify('تم حفظ صورة المنتج. جارٍ إنشاء التصميم…', 'success');
        const created = await request<{ id: string }>('/api/designs', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            assetId: currentAssetId,
            templateIds: selectedTemplates,
            category,
            name: (file?.name || 'تصميم جديد').replace(/\.[^.]+$/, '').slice(0, 150) || 'تصميم جديد'
          })
        });
        currentDesignId = created.id;
        setDesignId(currentDesignId);
      }
      const generated = await request<{ jobId: string; status: string }>(`/api/designs/${currentDesignId}/generate`, {
        method: 'POST', headers: { 'Idempotency-Key': crypto.randomUUID() }
      });
      setJob({ id: generated.jobId, designId: currentDesignId, status: generated.status, fidelityStatus: 'manual_review_required', errorCode: null, errorMessage: null, resultUrl: null, reviewRequired: false });
      notify('تم وضع الطلب في قائمة الانتظار. ستظهر النتيجة بعد اكتمال المعالجة.', 'success');
      setActiveTab('studio');
    } catch (error) {
      notify(error instanceof Error ? error.message : 'تعذر بدء عملية التوليد.', 'error');
    } finally { setBusy(false); }
  }

  async function reviewJob(action: 'approve' | 'reject') {
    if (!job) return;
    setBusy(true);
    try {
      await request(`/api/jobs/${job.id}/${action}`, { method: 'POST' });
      setJob({ ...job, status: action === 'approve' ? 'succeeded' : 'rejected', fidelityStatus: action === 'approve' ? 'approved_by_user' : 'rejected_by_user' });
      notify(action === 'approve' ? 'تم اعتماد النتيجة وحفظها في الأرشيف.' : 'تم رفض النتيجة. لن تظهر كتصميم معتمد.', action === 'approve' ? 'success' : 'info');
      await loadArchive();
    } catch (error) { notify(error instanceof Error ? error.message : 'تعذر حفظ قرار المراجعة.', 'error'); }
    finally { setBusy(false); }
  }

  async function deleteDesign(id: string) {
    if (!window.confirm('هل تريد حذف هذا التصميم؟ لا يمكن التراجع عن الحذف.')) return;
    try {
      await request(`/api/designs/${id}`, { method: 'DELETE' });
      setArchive(items => items.filter(item => item.id !== id));
      notify('تم حذف التصميم.', 'success');
    } catch (error) { notify(error instanceof Error ? error.message : 'تعذر حذف التصميم.', 'error'); }
  }

  async function openDesign(id: string) {
    try {
      const detail = await request<{
        design: { id: string; name: string; category: string; status: string; garmentAssetId: string; garmentUrl: string; garmentWidth: number; garmentHeight: number; garmentSize: number };
        templates: Array<{ id: string; name: string; pose: Template['pose']; category: string }>;
        jobs: Array<{ id: string; status: string; fidelityStatus: string; errorCode: string | null; errorMessage: string | null; outputAssetId: string | null; resultUrl: string | null }>;
      }>(`/api/designs/${id}`);
      const design = detail.design;
      setFile(null);
      if (fileInput.current) fileInput.current.value = '';
      setPreviewUrl(design.garmentUrl);
      setImageInfo({
        width: design.garmentWidth,
        height: design.garmentHeight,
        size: `${(Number(design.garmentSize) / 1024 / 1024).toFixed(2)} MB`
      });
      setAssetId(design.garmentAssetId);
      setDesignId(design.id);
      setCategory(design.category);
      setSelectedTemplates(detail.templates.map(item => item.id));
      const latest = detail.jobs[0];
      setJob(latest ? {
        id: latest.id, designId: design.id, status: latest.fidelityStatus === 'rejected_by_user' ? 'rejected' : latest.status,
        fidelityStatus: latest.fidelityStatus, errorCode: latest.errorCode,
        errorMessage: latest.errorMessage, resultUrl: latest.resultUrl,
        reviewRequired: latest.status === 'review'
      } : null);
      setActiveTab('studio');
      notify('تم فتح التصميم المحفوظ. يمكنك مراجعة النتيجة أو إعادة التوليد.', 'success');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      notify(error instanceof Error ? error.message : 'تعذر فتح التصميم المحفوظ.', 'error');
    }
  }

  async function signOut() {
    try { await request('/api/auth/logout', { method: 'POST' }); window.location.reload(); }
    catch (error) { notify(error instanceof Error ? error.message : 'تعذر تسجيل الخروج.', 'error'); }
  }

  if (authLoading) return <div className="boot-screen"><div className="brand-mark">M</div><LoaderCircle className="spin"/><span>تهيئة استوديو Modella…</span></div>;

  return (
    <div className="app-shell" dir="rtl">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Modella - الرئيسية"><span className="brand-mark">M</span><span>modella</span></a>
        <nav className={showMobileMenu ? 'nav-links open' : 'nav-links'} aria-label="التنقل الرئيسي">
          <button className={activeTab === 'studio' ? 'nav-link active' : 'nav-link'} onClick={() => { setActiveTab('studio'); setShowMobileMenu(false); }}>استوديو التصميم</button>
          <button className={activeTab === 'archive' ? 'nav-link active' : 'nav-link'} onClick={() => { setActiveTab('archive'); void loadArchive(); setShowMobileMenu(false); }}>أرشيف تصاميمي</button>
        </nav>
        <div className="top-actions">
          {user ? <><span className="user-chip"><UserRound size={15}/>{user.name || user.email || 'حسابي'}</span><button className="icon-button" onClick={signOut} aria-label="تسجيل الخروج" title="تسجيل الخروج"><LogOut size={17}/></button></> : <button className="login-button" onClick={() => { window.location.href = '/api/auth/login'; }}><LogIn size={17}/> تسجيل الدخول</button>}
        </div>
        <button className="mobile-menu" onClick={() => setShowMobileMenu(value => !value)} aria-label="فتح القائمة"><Menu/></button>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-dot"/> استوديو تصوير الأزياء الافتراضي</div>
            <h1>قطعتك كما هي.<br/><em>بإطلالة جديدة.</em></h1>
            <p>اعرض منتجاتك على عارضات أزياء مرجعيات، مع الحفاظ على صورة القطعة الأصلية ومراجعة النتيجة قبل اعتمادها.</p>
            <div className="hero-actions">
              <button className="button-primary" onClick={() => { setActiveTab('studio'); document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' }); }}>ابدأ التصميم <ArrowLeft size={17}/></button>
              <span className="hero-note"><ShieldCheck size={16}/> ملفات خاصة ومحمية</span>
            </div>
          </div>
          <div className="hero-art" aria-label="رسم توضيحي للعرض الافتراضي، وليس نتيجة توليد حقيقية">
            <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
            <div className="art-card card-back"><div className="art-silhouette silhouette-back"/><span>ANGLE 02</span></div>
            <div className="art-card card-front"><div className="art-silhouette silhouette-front"/><span>STUDIO / 01</span></div>
            <div className="art-stamp"><Sparkles size={18}/><span>VIRTUAL<br/>TRY-ON</span></div>
            <small className="art-disclaimer">تصوّر بصري توضيحي · ليس نتيجة مولّدة</small>
          </div>
        </section>

        <section className="trust-strip">
          <div><ShieldCheck/><span><b>خصوصية الملفات</b><small>لا تظهر صورك للآخرين</small></span></div>
          <div><Database/><span><b>أرشيف دائم</b><small>تصاميمك تبقى محفوظة</small></span></div>
          <div><WandSparkles/><span><b>مراجعة بشرية</b><small>لا نعتمد النتيجة تلقائياً</small></span></div>
          <div className="engine-state"><span className={system?.vton.ready ? 'state-indicator online' : 'state-indicator offline'}/><span><b>{system?.vton.ready ? 'المحرك جاهز' : 'المحرك غير مهيأ'}</b><small>{system?.vton.message || 'جارٍ التحقق من حالة الخدمة'}</small></span></div>
        </section>

        {message && <div className={`message-banner ${messageKind}`} role="status"><span>{messageKind === 'error' ? <CircleAlert size={18}/> : messageKind === 'success' ? <CheckCircle2 size={18}/> : <Clock3 size={18}/>}</span><p>{message}</p><button onClick={() => setMessage('')} aria-label="إغلاق الرسالة"><X size={16}/></button></div>}

        {activeTab === 'studio' ? (
          <section id="workspace" className="workspace-section">
            <div className="section-heading"><div><span className="section-kicker">مساحة العمل</span><h2>أنشئ جلسة تصوير جديدة</h2><p>أكمل الخطوات ثم ابدأ التوليد على الخادم المرتبط بحسابك.</p></div><span className="step-count">01 <i>/</i> 04</span></div>
            {!user ? (
              <div className="login-gate"><div className="gate-icon"><UserRound/></div><h3>سجّل الدخول لبدء مشروعك</h3><p>يلزم حساب موثّق لحفظ الصور والتصاميم بصورة خاصة.</p><button className="button-primary" onClick={() => { window.location.href = '/api/auth/login'; }}>تسجيل الدخول الآمن <ArrowLeft size={17}/></button></div>
            ) : (
              <>
                <div className="workspace-grid">
                  <section className="surface upload-panel">
                    <div className="surface-heading"><span className="number-badge">01</span><div><h3>صورة المنتج</h3><p>ابدأ بصورة واحدة واضحة للقطعة.</p></div><Shirt className="heading-icon"/></div>
                    <div className={previewUrl ? 'upload-zone has-image' : 'upload-zone'} onClick={() => !previewUrl && fileInput.current?.click()} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); void chooseFile(event.dataTransfer.files?.[0]); }}>
                      <input ref={fileInput} type="file" accept="image/jpeg,image/png,image/webp" onChange={event => void chooseFile(event.target.files?.[0])}/>
                      {previewUrl ? <><img className="garment-preview" src={previewUrl} alt="صورة القطعة" onClick={() => setZoomImage(previewUrl)}/><div className="preview-overlay"><span><CheckCircle2 size={16}/> {file ? 'معاينة محلية ناجحة' : 'صورة محفوظة'}</span><button onClick={event => { event.stopPropagation(); clearFile(); }} aria-label="إزالة الصورة"><Trash2 size={16}/></button></div></> : <div className="upload-placeholder"><div className="upload-icon"><CloudUpload size={28}/></div><b>اسحب الصورة إلى هنا</b><span>أو انقر لاختيار ملف من جهازك</span><small>JPG · PNG · WEBP <i/> حتى 12 MB</small></div>}
                    </div>
                    {imageInfo && <div className="image-meta"><span><FileImage size={14}/> {imageInfo.width} × {imageInfo.height}</span><span>{imageInfo.size}</span><span>الأصل محفوظ دون تعديل</span></div>}
                    <div className="category-block"><div className="field-label">فئة القطعة</div><div className="category-options">{categoryOptions.map(option => <button key={option.value} className={category === option.value ? 'category-option selected' : 'category-option'} onClick={() => { setCategory(option.value); setSelectedTemplates([]); setDesignId(''); setJob(null); }}><b>{option.label}</b><small>{option.sub}</small>{category === option.value && <Check size={15}/>}</button>)}</div></div>
                    <div className="upload-footer"><span><ShieldCheck size={15}/> {assetId ? 'الصورة محفوظة في حسابك الخاص.' : 'لا يتم رفع الصورة إلا بعد موافقتك.'}</span><button className="text-button" onClick={() => fileInput.current?.click()}><ImagePlus size={15}/> {previewUrl ? 'تغيير الصورة' : 'اختيار صورة'}</button></div>
                  </section>

                  <section className="surface models-panel">
                    <div className="surface-heading"><span className="number-badge">02</span><div><h3>اختر العارضة</h3><p>صور مرجعية حقيقية للعارضات البالغات.</p></div><UserRound className="heading-icon"/></div>
                    {templates.length ? <><div className="selection-note">اختر عارضة واحدة، أو عارضتين بوضعيتين مختلفتين لعرضين منفصلين.</div><div className="template-grid">{templates.filter(template => template.category === 'all' || template.category === category).map(template => <button key={template.id} className={selectedTemplates.includes(template.id) ? 'template-card selected' : 'template-card'} onClick={() => toggleTemplate(template.id)}><img src={template.imageUrl} alt={template.name}/><span className="template-check">{selectedTemplates.includes(template.id) ? <Check size={14}/> : null}</span><b>{template.name}</b><small>{poseLabels[template.pose] || template.pose}</small></button>)}</div></> : <div className="template-empty"><div className="empty-icon"><UserRound size={25}/></div><b>لم تتم إضافة قوالب بعد</b><p>يجب على مسؤول المنصة رفع صور عارضات بالغات وتوثيق حقوق استخدامها قبل ظهورها هنا.</p></div>}
                    <div className="setting-list"><div><span>عدد المراجع المختارة</span><b>{selectedTemplates.length} / 2</b></div><div><span>الخلفية</span><b>الحفاظ على خلفية القالب</b></div><div><span>حالة محرك التوليد</span><b className={system?.vton.ready ? 'good-text' : 'warning-text'}>{system?.vton.ready ? 'متاح' : 'غير متاح'}</b></div></div>
                  </section>
                </div>

                <section className="review-config surface">
                  <div className="surface-heading compact"><span className="number-badge">03</span><div><h3>مراجعة الإعدادات</h3><p>لن نخترع جهة خلفية غير ظاهرة في الصور المرجعية.</p></div></div>
                  <div className="config-summary"><div><span>صورة المنتج</span><b>{file ? file.name : assetId ? 'صورة محفوظة في الأرشيف' : 'لم يتم اختيار صورة'}</b></div><div><span>العارضات</span><b>{selectedTemplates.length ? selectedTemplateObjects.map(item => `${item.name} · ${poseLabels[item.pose]}`).join('، ') : 'لم يتم الاختيار'}</b></div><div><span>شكل النتيجة</span><b>{selectedTemplates.length === 2 ? 'لوحتان مرجعيتان جنباً إلى جنب' : 'صورة واحدة وفق القالب المختار'}</b></div></div>
                  <div className="config-actions"><span><ShieldCheck size={16}/> النتيجة الجديدة تبقى قيد المراجعة حتى اعتمادك لها.</span><button className="button-primary generate-button" disabled={(!file && !assetId) || !selectedTemplates.length || !system?.vton.ready || busy || (job && ['queued','processing','review'].includes(job.status))} onClick={() => void startGeneration()}>{busy ? <LoaderCircle className="spin" size={17}/> : <Sparkles size={17}/>} {busy ? 'جارٍ التجهيز…' : 'ابدأ التوليد'} <ArrowLeft size={16}/></button></div>
                  {!system?.vton.ready && <div className="engine-warning"><CircleAlert size={16}/><span>{system?.vton.message || 'لم يتم ربط نموذج توليد محلي مرخّص بعد.'}</span></div>}
                </section>

                {job && <section className="result-section surface"><div className="surface-heading"><span className="number-badge">04</span><div><h3>حالة النتيجة</h3><p>متابعة مباشرة لحالة الطلب المحفوظ في قائمة الانتظار.</p></div><span className={`status-pill ${statusTone(job.status)}`}>{statusLabels[job.status] || job.status}</span></div>
                  {job.status === 'queued' || job.status === 'processing' ? <div className="processing-state"><LoaderCircle className="spin"/><div><b>{job.status === 'queued' ? 'طلبك في قائمة الانتظار' : 'النموذج يعالج الصور الآن'}</b><p>لا تغلق الحساب؛ يمكنك العودة إلى هذا التصميم من الأرشيف.</p></div></div> : null}
                  {['review','succeeded','rejected'].includes(job.status) && job.resultUrl && <><div className="comparison-grid"><div className="comparison-image"><span>صورة القطعة الأصلية</span><img src={previewUrl} alt="القطعة الأصلية للمقارنة" onClick={() => setZoomImage(previewUrl)}/></div><div className="comparison-image"><span>النتيجة على العارضة</span><img src={job.resultUrl} alt="نتيجة تجربة الملابس الافتراضية" onClick={() => setZoomImage(job.resultUrl!)} /></div></div><div className="result-caption"><b>{job.status === 'review' ? 'نتيجة مولّدة — غير معتمدة بعد' : job.status === 'rejected' ? 'نتيجة مرفوضة — غير معتمدة' : 'نتيجة معتمدة من المستخدم'}</b><span>افحص اللون والقصة والنقوش والشعارات والجيوب والخياطة؛ الاعتماد قرارك أنت.</span></div><div className="result-actions"><a className="button-secondary" href={job.resultUrl} download="modella-result.png"><ArrowDownToLine size={16}/> تنزيل النتيجة</a><a className="button-secondary" href={previewUrl} download="modella-original"><ArrowDownToLine size={16}/> تنزيل الأصل</a>{job.status === 'review' && <><button className="button-secondary danger-outline" disabled={busy} onClick={() => void reviewJob('reject')}><X size={16}/> رفض النتيجة</button><button className="button-primary" disabled={busy} onClick={() => void reviewJob('approve')}><Check size={16}/> اعتماد النتيجة</button></>}</div></>}
                  {['failed','rejected'].includes(job.status) && <div className="failed-state"><CircleAlert/><div><b>{job.status === 'rejected' ? 'تم رفض النتيجة' : 'لم تكتمل عملية التوليد'}</b><p>{job.errorMessage || (job.status === 'rejected' ? 'لن تظهر النتيجة كتصميم معتمد.' : 'لم يتم حفظ نتيجة. راجع حالة المحرك أو حاول لاحقاً.')}</p></div></div>}
                  {job.status === 'succeeded' && <div className="approved-state"><CheckCircle2/><span>تم اعتماد النتيجة وحفظها في أرشيف تصاميمك.</span></div>}
                </section>}
              </>
            )}
          </section>
        ) : (
          <section className="workspace-section archive-section">
            <div className="section-heading"><div><span className="section-kicker">مساحة محفوظاتك</span><h2>أرشيف تصاميمي</h2><p>تظهر هنا التصاميم والنتائج المرتبطة بحسابك فقط.</p></div><button className="button-secondary refresh-button" onClick={() => void loadArchive()} disabled={archiveLoading}>{archiveLoading ? <LoaderCircle className="spin"/> : <RefreshCw/>} تحديث الأرشيف</button></div>
            {!user ? <div className="login-gate"><div className="gate-icon"><LockIcon/></div><h3>سجّل الدخول لعرض أرشيفك</h3><p>لا يمكن الوصول إلى صور أو تصاميم أي مستخدم آخر.</p><button className="button-primary" onClick={() => { window.location.href = '/api/auth/login'; }}>تسجيل الدخول</button></div> : archiveLoading ? <div className="loading-panel"><LoaderCircle className="spin"/> جارٍ تحميل تصاميمك…</div> : archive.length ? <div className="archive-grid">{archive.map(item => <article className="archive-card" key={item.id}><div className="archive-images"><img src={item.resultUrl || item.garmentUrl} alt={item.name} onClick={() => setZoomImage(item.resultUrl || item.garmentUrl)}/>{item.resultUrl && <span>نتيجة</span>}</div><div className="archive-content"><div className="archive-title-row"><h3>{item.name}</h3><span className={`status-pill ${statusTone(item.status)}`}>{statusLabels[item.status] || item.status}</span></div><p>{categoryOptions.find(option => option.value === item.category)?.label || item.category} · {formatDate(item.createdAt)}</p>{item.errorMessage && item.status !== 'rejected' && <small className="archive-error">{item.errorMessage}</small>}<div className="archive-actions"><button onClick={() => void openDesign(item.id)}><Images size={15}/> فتح / إعادة التوليد</button>{item.resultUrl && <a href={item.resultUrl} download={`${item.name}.png`}><ArrowDownToLine size={15}/> تنزيل النتيجة</a>}<a href={item.garmentUrl} download={`${item.name}-original`}><ArrowDownToLine size={15}/> تنزيل الأصل</a><button onClick={() => void deleteDesign(item.id)}><Trash2 size={15}/> حذف</button></div></div></article>)}</div> : <div className="empty-archive"><div className="empty-icon"><FolderOpen size={27}/></div><h3>لا توجد تصاميم محفوظة بعد</h3><p>عندما تبدأ أول جلسة تصوير، ستظهر نتائجك هنا مع حالتها وتاريخ إنشائها.</p><button className="button-primary" onClick={() => setActiveTab('studio')}>ابدأ أول تصميم <ArrowLeft size={16}/></button></div>}
          </section>
        )}

        <section className="how-section"><div className="how-heading"><span className="section-kicker">خطوات واضحة</span><h2>من الصورة إلى النتيجة</h2></div><div className="how-grid"><article><span>01</span><h3>ارفع صورة القطعة</h3><p>تعرض المعاينة محلياً أولاً، ثم ترفع الملف الأصلي بعد موافقتك.</p></article><article><span>02</span><h3>اختر صورة العارضة</h3><p>تُستخدم صور مرجعية فعلية ومرخّصة، ولا تُنشأ زوايا غير متاحة.</p></article><article><span>03</span><h3>راجع واعتمد</h3><p>افحص التفاصيل بصرياً قبل اعتماد الصورة وحفظها كتصميم نهائي.</p></article></div></section>
      </main>
      {zoomImage && <div className="image-lightbox" role="dialog" aria-modal="true" aria-label="تكبير الصورة" onClick={() => setZoomImage(null)}><button onClick={() => setZoomImage(null)} aria-label="إغلاق الصورة"><X size={22}/></button><img src={zoomImage} alt="عرض مكبّر للصورة" onClick={event => event.stopPropagation()}/></div>}
      <footer className="footer"><a className="brand" href="#top"><span className="brand-mark">M</span><span>modella</span></a><span>تصوير أزياء افتراضي · صورك وقراراتك تحت سيطرتك</span><a href="/health" target="_blank" rel="noreferrer">حالة الخدمة <ExternalLink size={13}/></a></footer>
    </div>
  );
}

function LockIcon() {
  return <ShieldCheck size={24}/>;
}
