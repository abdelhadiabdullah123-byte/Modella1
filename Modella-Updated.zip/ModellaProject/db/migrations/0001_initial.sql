CREATE TABLE IF NOT EXISTS users (
  id CHAR(36) PRIMARY KEY,
  oidc_sub VARCHAR(255) NOT NULL UNIQUE,
  email VARCHAR(320) NULL,
  display_name VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS assets (
  id CHAR(36) PRIMARY KEY,
  owner_id CHAR(36) NOT NULL,
  object_key VARCHAR(512) NOT NULL UNIQUE,
  kind ENUM('garment','template','result') NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_size BIGINT UNSIGNED NOT NULL,
  width INT UNSIGNED NOT NULL,
  height INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_assets_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_assets_owner_created (owner_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS templates (
  id CHAR(36) PRIMARY KEY,
  owner_id CHAR(36) NOT NULL,
  asset_id CHAR(36) NOT NULL,
  name VARCHAR(160) NOT NULL,
  description TEXT NULL,
  pose ENUM('front','three_quarter','side') NOT NULL,
  category ENUM('tops','bottoms','one-pieces','all') NOT NULL DEFAULT 'all',
  adult_verified BOOLEAN NOT NULL DEFAULT FALSE,
  rights_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
  provenance TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_templates_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_templates_asset FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE RESTRICT,
  INDEX idx_templates_pose_category (pose, category)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS designs (
  id CHAR(36) PRIMARY KEY,
  owner_id CHAR(36) NOT NULL,
  name VARCHAR(160) NOT NULL,
  garment_asset_id CHAR(36) NOT NULL,
  category ENUM('tops','bottoms','one-pieces') NOT NULL,
  background ENUM('keep_template') NOT NULL DEFAULT 'keep_template',
  status ENUM('draft','queued','processing','review','approved','rejected','failed') NOT NULL DEFAULT 'draft',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_designs_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_designs_garment FOREIGN KEY (garment_asset_id) REFERENCES assets(id) ON DELETE RESTRICT,
  INDEX idx_designs_owner_created (owner_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS design_templates (
  design_id CHAR(36) NOT NULL,
  template_id CHAR(36) NOT NULL,
  position SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (design_id, template_id),
  CONSTRAINT fk_dt_design FOREIGN KEY (design_id) REFERENCES designs(id) ON DELETE CASCADE,
  CONSTRAINT fk_dt_template FOREIGN KEY (template_id) REFERENCES templates(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS generation_jobs (
  id CHAR(36) PRIMARY KEY,
  design_id CHAR(36) NOT NULL,
  owner_id CHAR(36) NOT NULL,
  idempotency_key VARCHAR(128) NOT NULL,
  status ENUM('queued','processing','review','succeeded','failed') NOT NULL DEFAULT 'queued',
  attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  output_asset_id CHAR(36) NULL,
  fidelity_status ENUM('not_checked','manual_review_required','approved_by_user','rejected_by_user') NOT NULL DEFAULT 'not_checked',
  error_code VARCHAR(80) NULL,
  error_message VARCHAR(500) NULL,
  started_at TIMESTAMP NULL,
  finished_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_jobs_design FOREIGN KEY (design_id) REFERENCES designs(id) ON DELETE CASCADE,
  CONSTRAINT fk_jobs_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_jobs_output FOREIGN KEY (output_asset_id) REFERENCES assets(id) ON DELETE SET NULL,
  UNIQUE KEY uq_job_idempotency (owner_id, idempotency_key),
  INDEX idx_jobs_queue (status, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id CHAR(36) NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id VARCHAR(80) NULL,
  details JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_user_created (user_id, created_at)
) ENGINE=InnoDB;
