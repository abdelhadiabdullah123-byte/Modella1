# توثيق API — Modella

كل المسارات نسبية إلى نفس نطاق الواجهة. الجلسة تحفظ في Cookie باسم `modella.sid` وتكون HttpOnly وSameSite=Lax. كل مسارات التصميم والرفع والملفات الخاصة تتطلب جلسة OIDC صحيحة. يجب إرسال الطلبات من نفس Origin.

## الحالة والمصادقة

| Method | Path | الوصف |
|---|---|---|
| GET | `/health` | صحة API وMySQL وMinIO |
| GET | `/api/system/status` | حالة المحرك والمصادقة والتخزين |
| GET | `/api/auth/me` | حالة الجلسة والمستخدم الحالي |
| GET | `/api/auth/login` | بدء OIDC Authorization Code + PKCE |
| GET | `/api/auth/callback` | استقبال OIDC callback والتحقق من state/nonce |
| POST | `/api/auth/logout` | إنهاء الجلسة |

## الأصول والقوالب

| Method | Path | الوصف |
|---|---|---|
| GET | `/api/templates` | القوالب البالغة المعتمدة والموثقة |
| POST | `/api/modella/assets` | رفع أصل الملابس، multipart field `file` |
| GET | `/api/modella/assets/:assetId` | بث ملف خاص بعد فحص الملكية |
| POST | `/api/admin/templates` | إضافة قالب للمسؤول فقط |

حقول multipart لمسار القالب: `file`, `name`, `description` (اختياري), `pose` (`front` أو `three_quarter` أو `side`), `category` (`tops`, `bottoms`, `one-pieces`, `all`), `adultVerified=true`, `rightsConfirmed=true`, `provenance` (مصدر وحقوق موثقة). لا يكفي اختيار `true` دون وجود توثيق فعلي لدى المسؤول.

## التصاميم والوظائف

| Method | Path | الوصف |
|---|---|---|
| POST | `/api/designs` | إنشاء تصميم `{assetId, templateIds, category, name}` |
| GET | `/api/designs` | قائمة تصاميم المستخدم |
| GET | `/api/designs/:id` | تفاصيل التصميم ومهامه |
| DELETE | `/api/designs/:id` | حذف التصميم وحذف الأصول غير المستخدمة فقط |
| POST | `/api/designs/:id/generate` | إضافة مهمة توليد؛ يتطلب `Idempotency-Key` اختياري |
| GET | `/api/jobs/:id` | حالة المهمة والنتيجة عند توفرها |
| POST | `/api/jobs/:id/approve` | اعتماد نتيجة بعد مراجعة المستخدم |
| POST | `/api/jobs/:id/reject` | رفض نتيجة مراجعة |

حالات المهمة: `queued`, `processing`, `review`, `succeeded`, `failed`. لا تتحول المهمة إلى `succeeded` إلا بعد أن يحفظ العامل ملف النتيجة ويراجع المستخدم النتيجة ويعتمدها.

## tRPC

المسار `/api/trpc` يوفر:

- `systemStatus` — حالة الخدمات ومحرك VTON (تستخدمه الواجهة لتحديث حالة العامل).
- `currentUser` — حالة المستخدم الحالي.

التطبيق يحتفظ بواجهات REST لرفع الصور وبث الأصول وتحميل الملفات؛ ويستخدم tRPC للواجهات typed RPC.

## حالات HTTP الشائعة

- `401`: لا توجد جلسة موثقة.
- `403`: الطلب من Origin غير مسموح أو صلاحية مسؤول مفقودة.
- `404`: التصميم/المهمة/الأصل غير موجود أو ليس مملوكاً للمستخدم.
- `409`: تعارض حالة المهمة أو مفتاح idempotency.
- `413`: حجم ملف أعلى من الحد.
- `429`: تجاوز معدل الرفع أو التوليد.
- `503`: محرك VTON غير جاهز؛ لا يتم إنشاء نتيجة وهمية أو إدخال مهمة جديدة.
