# إعداد محرك تجربة الملابس المحلي

## النموذج المدمج كخيار

يحتوي العامل على adapter اختياري لـFASHN VTON v1.5. المصدر الرسمي يذكر واجهة `TryOnPipeline` وتوقع `person_image`, `garment_image`, `category`, وملف صورة ضمن `result.images[0]`.

المصادر الرسمية:

- https://github.com/fashn-AI/fashn-vton-1.5
- https://huggingface.co/fashn-ai/fashn-vton-1.5
- https://fashn.ai/research/vton-1-5

## خطوات التهيئة

1. راجع `LICENSES.md` بما فيه ترخيص Human Parser التابع. لا تتجاوز قفل الترخيص.
2. ثبّت commit SHA محدداً راجعته؛ لا تعتمد `main` أو `master` في النشر. اضبط `FASHN_GIT_REF` إلى SHA الثابت. يرفض Dockerfile القيم المتغيرة والافتراضية عند تفعيل التثبيت.
3. بعد ضبط `INSTALL_FASHN=1`, أعد بناء عامل `vton-worker`.
4. استخدم commit SHA نفسه الذي وضعته في `FASHN_GIT_REF` لتنزيل الأوزان وفق خطوات المستودع الرسمي. مثال بعد استبدال المسار وSHA الفعليين:

   ```bash
   git clone https://github.com/fashn-AI/fashn-vton-1.5.git /tmp/fashn-vton-1.5
   cd /tmp/fashn-vton-1.5
   git checkout <reviewed-40-character-commit-sha>
   python -m venv .venv
   . .venv/bin/activate
   pip install -e .
   python scripts/download_weights.py --weights-dir /absolute/path/to/ModellaProject/models/fashn-vton-1.5
   ```

   يجب أن تتوفر `model.safetensors` ومجلد `dwpose/`. يتم تنزيل أوزان Human Parser تلقائياً عند أول تشغيل إلى Hugging Face cache؛ راجع ترخيصها بصورة مستقلة. الأوزان ليست مضمنة أو محفوظة في Git.
5. راجع CPU/GPU وإصدار CUDA وتوافق ONNX Runtime. تشغيل GPU عبر Compose يتطلب NVIDIA Container Toolkit ودعم `gpus: all`. في وضع CPU اضبط `ALLOW_CPU_INFERENCE=1` قبل بناء العامل؛ يقوم Dockerfile عندها باستبدال `onnxruntime-gpu` بحزمة `onnxruntime` المتوافقة مع CPU. أعد البناء عند تغيير هذا الخيار.
6. بعد استكمال مراجعة الترخيص فقط، اضبط `VTON_PROVIDER=fashn` و`VTON_LICENSE_REVIEWED=1` ثم أعد إنشاء العامل.
7. تحقق من `/api/system/status` أن `vton.ready=true` قبل إرسال طلب فعلي.

## الموارد والقيود

تشير بطاقة النموذج إلى نحو 8GB VRAM كمتطلب إرشادي، وإخراج يقارب 576×864، وسرعة مختبرية تختلف باختلاف GPU. تذكر الوثائق احتمال بقاء أثر من اللباس السابق في تغييرات الطول أو القصات الضخمة إلى الضيقة، وأن الحفاظ على شكل الجسم غير مثالي دائماً. لا تضف upscaling بوصفه استعادة لتفاصيل لم ينتجها النموذج.

## فحص النتيجة

العامل يحفظ صورة واحدة عند اختيار عارضة واحدة، أو يضع ناتجي صورتين مستقلتين في لوحة واحدة عند اختيار مرجعين مختلفين. لا ينشئ صورة خلفية غير متوفرة. كل نتيجة محفوظة بحالة `manual_review_required` ولا يوجد حالياً مقياس fidelity معاير على مجموعة بيانات حقيقية؛ لذلك الاعتماد النهائي قرار المستخدم وليس شهادة آلية بالتطابق.

## إيقاف المحرك

القيم الافتراضية (`VTON_PROVIDER=none`, `VTON_LICENSE_REVIEWED=0`, `INSTALL_FASHN=0`) توقف التوليد بأمان. لا تحوّل المهمة إلى نجاح عند غياب الأوزان أو GPU أو فشل inference.
