from pathlib import Path
import sys

# Make the service package importable for pytest from any working directory.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
