from PIL import Image

from app.images import compose_views, normalize_rgb


def test_normalize_rgb_respects_dimensions_and_mode():
    source = Image.new("RGBA", (120, 180), (20, 40, 60, 255))
    result = normalize_rgb(source)
    assert result.mode == "RGB"
    assert result.size == (120, 180)


def test_one_view_is_not_invented_or_recomposed():
    source = Image.new("RGB", (120, 180), "red")
    result = compose_views([source])
    assert result.size == source.size
    assert result.getpixel((10, 10)) == (255, 0, 0)


def test_two_views_are_composited_side_by_side():
    first = Image.new("RGB", (100, 180), "red")
    second = Image.new("RGB", (100, 180), "blue")
    result = compose_views([first, second])
    assert result.size == (224, 180)
    assert result.getpixel((10, 10)) == (255, 0, 0)
    assert result.getpixel((210, 10)) == (0, 0, 255)


def test_transparency_is_composited_on_white():
    source = Image.new("RGBA", (80, 90), (255, 0, 0, 0))
    result = normalize_rgb(source)
    assert result.mode == "RGB"
    assert result.getpixel((20, 20)) == (255, 255, 255)


def test_tiny_images_are_rejected():
    source = Image.new("RGB", (32, 48), "white")
    try:
        normalize_rgb(source)
    except ValueError as exc:
        assert "صغيرة" in str(exc)
    else:
        raise AssertionError("A too-small image must be rejected")


def test_exif_orientation_is_applied():
    source = Image.new("RGB", (80, 120), "white")
    exif = Image.Exif()
    exif[274] = 6  # Orientation 6: rotate 90 degrees clockwise.
    import io
    buffer = io.BytesIO()
    source.save(buffer, format="JPEG", exif=exif)
    buffer.seek(0)
    from PIL import Image as PILImage
    with PILImage.open(buffer) as decoded:
        result = normalize_rgb(decoded)
    assert result.size == (120, 80)


def test_images_over_pixel_budget_are_rejected(monkeypatch):
    # Exercise the safety guard without allocating a huge raster.
    from app import images

    class OversizedImage:
        width = 12001
        height = 12001
        info = {}

        def getbands(self):
            return ("R", "G", "B")

        def convert(self, mode):
            return self

    monkeypatch.setattr(images.ImageOps, "exif_transpose", lambda image: image)
    try:
        normalize_rgb(OversizedImage())
    except ValueError as exc:
        assert "تتجاوز" in str(exc)
    else:
        raise AssertionError("An oversized image must be rejected")


def test_composite_preserves_each_view_aspect_ratio():
    first = Image.new("RGB", (100, 200), "red")
    second = Image.new("RGB", (150, 200), "blue")
    result = compose_views([first, second])
    # Both panels are normalized to the same height; the source ratios remain intact.
    assert result.size == (274, 200)
    assert result.getpixel((10, 10)) == (255, 0, 0)
    assert result.getpixel((120, 10)) == (255, 255, 255)
    assert result.getpixel((130, 10)) == (0, 0, 255)


def test_composite_rejects_empty_view_list():
    try:
        compose_views([])
    except ValueError as exc:
        assert "لا توجد صور" in str(exc)
    else:
        raise AssertionError("An empty view list must be rejected")
