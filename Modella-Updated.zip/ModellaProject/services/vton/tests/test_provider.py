from pathlib import Path

from app import provider


def test_provider_is_disabled_by_default(monkeypatch):
    monkeypatch.delenv("VTON_PROVIDER", raising=False)
    monkeypatch.delenv("VTON_LICENSE_REVIEWED", raising=False)
    ready, reason = provider.initialize_provider()
    assert ready is False
    assert "غير مفعّل" in reason
    assert provider.provider_status()["ready"] is False


def test_provider_requires_explicit_license_review(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("VTON_PROVIDER", "fashn")
    monkeypatch.setenv("VTON_LICENSE_REVIEWED", "0")
    monkeypatch.setenv("VTON_WEIGHTS_DIR", str(tmp_path))
    ready, reason = provider.initialize_provider()
    assert ready is False
    assert "مراجعة ترخيص" in reason


def test_provider_requires_model_weights_before_loading(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("VTON_PROVIDER", "fashn")
    monkeypatch.setenv("VTON_LICENSE_REVIEWED", "1")
    monkeypatch.setenv("VTON_WEIGHTS_DIR", str(tmp_path))
    ready, reason = provider.initialize_provider()
    assert ready is False
    assert "ملفات النموذج" in reason


def test_weight_check_requires_nonempty_model_and_dwpose(tmp_path: Path):
    weights = tmp_path / "weights"
    weights.mkdir()
    (weights / "model.safetensors").write_bytes(b"weights")
    (weights / "dwpose").mkdir()
    assert provider._weight_files_present(weights) is False
    (weights / "dwpose" / "model.bin").write_bytes(b"pose")
    assert provider._weight_files_present(weights) is True
