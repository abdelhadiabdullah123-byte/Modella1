from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI

from .provider import initialize_provider, provider_status
from .queue import expire_stale_jobs, process_one_job


def _poll_forever():
    async def run():
        last_recovery = 0.0
        while True:
            now = asyncio.get_running_loop().time()
            if now - last_recovery > 60:
                try:
                    await asyncio.to_thread(expire_stale_jobs)
                except Exception:
                    # Retry dependency failures on the next recovery interval.
                    pass
                last_recovery = now
            status = provider_status()
            if status["ready"]:
                try:
                    did_work = await asyncio.to_thread(process_one_job)
                except Exception:
                    # A transient database/storage error is retried; claimed jobs are
                    # eventually expired instead of being reported as successful.
                    did_work = False
                if not did_work:
                    await asyncio.sleep(2)
            else:
                await asyncio.sleep(5)
    return run()


@asynccontextmanager
async def lifespan(app: FastAPI):
    ready, reason = await asyncio.to_thread(initialize_provider)
    app.state.vton_ready = ready
    app.state.vton_reason = reason
    if ready:
        await asyncio.to_thread(expire_stale_jobs)
    task = asyncio.create_task(_poll_forever())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title="Modella VTON Worker", lifespan=lifespan)


@app.get("/health")
def health():
    return {"ok": True, **provider_status()}
