from __future__ import annotations

from PIL import Image, ImageOps


def normalize_rgb(image: Image.Image) -> Image.Image:
    image = ImageOps.exif_transpose(image)
    if "A" in image.getbands() or "transparency" in image.info:
        rgba = image.convert("RGBA")
        background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        image = Image.alpha_composite(background, rgba).convert("RGB")
    else:
        image = image.convert("RGB")
    if image.width < 64 or image.height < 64:
        raise ValueError("الصورة صغيرة جداً للمعالجة.")
    if image.width > 12000 or image.height > 12000 or image.width * image.height > 80_000_000:
        raise ValueError("أبعاد الصورة تتجاوز الحد الآمن للمعالجة.")
    return image


def compose_views(images: list[Image.Image]) -> Image.Image:
    """Place independent generated views side-by-side without inventing another angle."""
    if not images:
        raise ValueError("لا توجد صور لدمجها.")
    normalized = [normalize_rgb(image) for image in images]
    if len(normalized) == 1:
        return normalized[0]
    panel_height = max(image.height for image in normalized)
    panels = []
    for image in normalized:
        width = max(1, round(image.width * panel_height / image.height))
        panels.append(image.resize((width, panel_height), Image.Resampling.LANCZOS))
    gap = 24
    canvas = Image.new(
        "RGB",
        (sum(panel.width for panel in panels) + gap * (len(panels) - 1), panel_height),
        "white",
    )
    x = 0
    for panel in panels:
        canvas.paste(panel, (x, 0))
        x += panel.width + gap
    if canvas.width > 16000 or canvas.height > 12000 or canvas.width * canvas.height > 100_000_000:
        raise ValueError("الصورة المركبة تتجاوز حدود الدقة الآمنة.")
    return canvas
