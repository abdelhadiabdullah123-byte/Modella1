from __future__ import annotations

import io
import os
import tempfile
import uuid
from pathlib import Path

import mysql.connector
from minio import Minio
from PIL import Image, ImageOps

from .provider import generate
from .images import compose_views, normalize_rgb


def _db():
    return mysql.connector.connect(
        host=os.getenv("MYSQL_HOST", "mysql"),
        port=int(os.getenv("MYSQL_PORT", "3306")),
        user=os.environ["MYSQL_USER"],
        password=os.environ["MYSQL_PASSWORD"],
        database=os.environ["MYSQL_DATABASE"],
        autocommit=False,
    )


def _storage():
    return Minio(
        os.getenv("MINIO_ENDPOINT", "minio:9000"),
        access_key=os.environ["MINIO_ACCESS_KEY"],
        secret_key=os.environ["MINIO_SECRET_KEY"],
        secure=os.getenv("MINIO_USE_SSL", "0") == "1",
    )


def _claim_job() -> dict | None:
    conn = _db()
    try:
        cur = conn.cursor(dictionary=True)
        conn.start_transaction()
        cur.execute(
            "SELECT id,design_id,owner_id FROM generation_jobs "
            "WHERE status='queued' ORDER BY created_at LIMIT 1 FOR UPDATE SKIP LOCKED"
        )
        job = cur.fetchone()
        if not job:
            conn.rollback()
            return None
        cur.execute(
            "UPDATE generation_jobs SET status='processing',attempts=attempts+1,started_at=NOW(), "
            "error_code=NULL,error_message=NULL WHERE id=%s AND status='queued'",
            (job["id"],),
        )
        cur.execute("UPDATE designs SET status='processing' WHERE id=%s", (job["design_id"],))
        conn.commit()
        return job
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _job_inputs(job_id: str) -> tuple[dict, list[dict]]:
    conn = _db()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            "SELECT j.id,j.owner_id,j.design_id,d.category,a.object_key AS garment_key "
            "FROM generation_jobs j JOIN designs d ON d.id=j.design_id "
            "JOIN assets a ON a.id=d.garment_asset_id WHERE j.id=%s AND j.status='processing'",
            (job_id,),
        )
        design = cur.fetchone()
        if not design:
            raise RuntimeError("تعذر العثور على التصميم الجاري معالجته.")
        cur.execute(
            "SELECT t.id,t.pose,ta.object_key AS person_key FROM design_templates dt "
            "JOIN templates t ON t.id=dt.template_id JOIN assets ta ON ta.id=t.asset_id "
            "WHERE dt.design_id=%s AND t.adult_verified=1 AND t.rights_confirmed=1 ORDER BY dt.position",
            (design["design_id"],),
        )
        templates = cur.fetchall()
        cur.execute("SELECT COUNT(*) AS expected_count FROM design_templates WHERE design_id=%s", (design["design_id"],))
        expected_count = int(cur.fetchone()["expected_count"])
        if not templates or len(templates) != expected_count:
            raise RuntimeError("أحد قوالب العارضات غير متاح أو لم تعد حقوق استخدامه مؤكدة.")
        return design, templates
    finally:
        conn.close()


def _read_object(client: Minio, bucket: str, key: str) -> Image.Image:
    response = client.get_object(bucket, key)
    try:
        data = response.read()
    finally:
        response.close()
        response.release_conn()
    return normalize_rgb(Image.open(io.BytesIO(data)))


def _mark_failed(job: dict, code: str, message: str):
    conn = _db()
    try:
        cur = conn.cursor()
        cur.execute(
            "UPDATE generation_jobs SET status='failed',error_code=%s,error_message=%s,finished_at=NOW() "
            "WHERE id=%s AND status='processing'",
            (code[:80], message[:500], job["id"]),
        )
        cur.execute("UPDATE designs SET status='failed' WHERE id=%s", (job["design_id"],))
        conn.commit()
    finally:
        conn.close()


def expire_stale_jobs() -> None:
    """Fail jobs left in processing after a worker crash; never mark them as successful."""
    conn = _db()
    try:
        cur = conn.cursor()
        cur.execute(
            "UPDATE generation_jobs SET status='failed',error_code='WORKER_TIMEOUT', "
            "error_message='توقفت المعالجة قبل اكتمالها. أعد المحاولة.',finished_at=NOW() "
            "WHERE status='processing' AND started_at < NOW() - INTERVAL 45 MINUTE"
        )
        cur.execute(
            "UPDATE designs d JOIN generation_jobs j ON j.design_id=d.id "
            "SET d.status='failed' WHERE j.status='failed' AND j.error_code='WORKER_TIMEOUT' "
            "AND d.status='processing'"
        )
        conn.commit()
    finally:
        conn.close()


def process_one_job() -> bool:
    job = _claim_job()
    if not job:
        return False

    bucket = os.getenv("MINIO_BUCKET", "modella-private")
    result_object_key = None
    storage = None
    try:
        storage = _storage()
        design, templates = _job_inputs(job["id"])
        with tempfile.TemporaryDirectory(prefix="modella-vton-") as temp_dir:
            temp = Path(temp_dir)
            garment = _read_object(storage, bucket, design["garment_key"])
            generated = []
            for index, template in enumerate(templates):
                person = _read_object(storage, bucket, template["person_key"])
                output = generate(person, garment, design["category"])
                if not isinstance(output, Image.Image):
                    raise RuntimeError("أعاد النموذج مخرجاً غير متوقع.")
                output = ImageOps.exif_transpose(output).convert("RGB")
                output_path = temp / f"view-{index + 1}.png"
                output.save(output_path, format="PNG", optimize=True)
                # Reopen saved bytes to ensure the encoder produced a valid image.
                with Image.open(output_path) as checked:
                    checked.verify()
                generated.append(output)

            final_image = compose_views(generated)
            result_path = temp / "result.png"
            final_image.save(result_path, format="PNG", optimize=True)
            with Image.open(result_path) as checked:
                checked.verify()
            output_bytes = result_path.read_bytes()

        asset_id = str(uuid.uuid4())
        result_object_key = f"{job['owner_id']}/result/{asset_id}.png"
        storage.put_object(
            bucket,
            result_object_key,
            io.BytesIO(output_bytes),
            length=len(output_bytes),
            content_type="image/png",
            metadata={"Cache-Control": "private, no-store"},
        )

        conn = _db()
        try:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO assets (id,owner_id,object_key,kind,mime_type,file_size,width,height) "
                "VALUES (%s,%s,%s,'result','image/png',%s,%s,%s)",
                (asset_id, job["owner_id"], result_object_key, len(output_bytes), final_image.width, final_image.height),
            )
            cur.execute(
                "UPDATE generation_jobs SET status='review',fidelity_status='manual_review_required', "
                "output_asset_id=%s,error_code=NULL,error_message=NULL,finished_at=NOW() "
                "WHERE id=%s AND status='processing'",
                (asset_id, job["id"]),
            )
            if cur.rowcount != 1:
                raise RuntimeError("تعذر تثبيت نتيجة المهمة؛ ربما حُذف التصميم أثناء المعالجة.")
            cur.execute("UPDATE designs SET status='review' WHERE id=%s", (job["design_id"],))
            conn.commit()
        except Exception:
            conn.rollback()
            storage.remove_object(bucket, result_object_key)
            raise
        finally:
            conn.close()
        return True
    except Exception as exc:
        if result_object_key and storage is not None:
            try:
                storage.remove_object(bucket, result_object_key)
            except Exception:
                pass
        # Do not store secrets, object paths, or traceback content in user-visible errors.
        error_text = str(exc).lower()
        if isinstance(exc, MemoryError) or "out of memory" in error_text or "cuda error: memory" in error_text:
            safe_message = "نفدت ذاكرة الجهاز أثناء التوليد. أغلق العمليات الأخرى أو استخدم GPU بذاكرة أكبر."
        elif isinstance(exc, ValueError):
            safe_message = str(exc)[:420]
        else:
            safe_message = f"تعذر إكمال التوليد بسبب خطأ في المحرك ({type(exc).__name__}). لم يتم حفظ نتيجة ناجحة."
        _mark_failed(job, "VTON_INFERENCE_FAILED", safe_message)
        return True
