from __future__ import annotations

import os
from pathlib import Path
from typing import Any

MODEL_NAME = "FASHN VTON v1.5"
_pipeline: Any | None = None
_unavailable_reason = "لم يتم اختيار محرك توليد محلي."


def _weight_files_present(weights_dir: Path) -> bool:
    model_file = weights_dir / "model.safetensors"
    dwpose_dir = weights_dir / "dwpose"
    return model_file.is_file() and model_file.stat().st_size > 0 and dwpose_dir.is_dir() and any(item.is_file() and item.stat().st_size > 0 for item in dwpose_dir.rglob("*"))


def initialize_provider() -> tuple[bool, str]:
    """Load a locally installed model only after explicit third-party license review."""
    global _pipeline, _unavailable_reason

    if os.getenv("VTON_PROVIDER", "none").lower() != "fashn":
        _unavailable_reason = "محرك FASHN غير مفعّل في إعدادات الخادم."
        return False, _unavailable_reason

    if os.getenv("VTON_LICENSE_REVIEWED") != "1":
        _unavailable_reason = (
            "التشغيل متوقف حتى تتم مراجعة ترخيص جميع المكونات التابعة، "
            "بما فيها FASHN Human Parser، ثم ضبط VTON_LICENSE_REVIEWED=1."
        )
        return False, _unavailable_reason

    weights_dir = Path(os.getenv("VTON_WEIGHTS_DIR", "/models/fashn-vton-1.5")).resolve()
    if not _weight_files_present(weights_dir):
        _unavailable_reason = "ملفات النموذج أو DWPose غير موجودة في مجلد الأوزان المحدد."
        return False, _unavailable_reason

    try:
        import torch
        from fashn_vton import TryOnPipeline

        if not torch.cuda.is_available() and os.getenv("ALLOW_CPU_INFERENCE") != "1":
            _unavailable_reason = "لم يتم العثور على GPU متوافق. فعّل ALLOW_CPU_INFERENCE=1 لقبول التشغيل البطيء على CPU."
            return False, _unavailable_reason

        if torch.cuda.is_available():
            free_bytes, total_bytes = torch.cuda.mem_get_info(0)
            free_gib = free_bytes / (1024**3)
            total_gib = total_bytes / (1024**3)
            minimum_gib = float(os.getenv("MIN_GPU_MEMORY_GIB", "8.0"))
            if total_gib < minimum_gib or free_gib < minimum_gib:
                _unavailable_reason = (
                    f"ذاكرة GPU الحرة حالياً ({free_gib:.1f} GiB من {total_gib:.1f} GiB) "
                    f"أقل من الحد الإرشادي المطلوب ({minimum_gib:.1f} GiB)."
                )
                return False, _unavailable_reason

        _pipeline = TryOnPipeline(weights_dir=str(weights_dir))
        _unavailable_reason = ""
        return True, "جاهز"
    except Exception as exc:  # model import/load failures must never make jobs look successful
        _pipeline = None
        _unavailable_reason = f"تعذر تحميل محرك التوليد: {type(exc).__name__}. راجع سجلات عامل VTON."
        return False, _unavailable_reason


def provider_status() -> dict[str, Any]:
    ready = _pipeline is not None
    return {
        "ready": ready,
        "provider": "fashn" if os.getenv("VTON_PROVIDER", "none").lower() == "fashn" else "none",
        "model": MODEL_NAME if ready else None,
        "reason": None if ready else _unavailable_reason,
    }


def generate(person_image, garment_image, category: str):
    if _pipeline is None:
        raise RuntimeError(_unavailable_reason or "محرك VTON غير جاهز.")
    if category not in {"tops", "bottoms", "one-pieces"}:
        raise ValueError("Unsupported garment category")
    result = _pipeline(
        person_image=person_image,
        garment_image=garment_image,
        category=category,
    )
    if not getattr(result, "images", None):
        raise RuntimeError("لم يُرجع محرك VTON أي صورة.")
    return result.images[0]
